package com.maha.anu;

public abstract class Parser extends WordProcessor{
	// abstract class is a class
	public void displayNonAbstract()
	{
		System.out.println("We are Implementing this in Abstract Class");
	}
	public abstract void parse(String fileType);
	

}
