package com.maha.anu2;

public interface CreditCardAccount {

	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();
}
