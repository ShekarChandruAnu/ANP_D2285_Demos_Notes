package com.maha.anu2;

public interface Insurance {

	public void openPolicy();
	public void terminatePolicy();
	public void calculatePremium();
}
