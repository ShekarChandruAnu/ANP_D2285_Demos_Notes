package com.maha.anu2;

public class InterestCalculator {
	public void showInterestPolicy()
	{
		System.out.println("Interest Calculation Policy is....");
	}
}
