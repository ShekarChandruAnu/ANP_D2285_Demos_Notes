package com.maha.anu;

public class PointManipulator {

	//This method returns an Array of Objects of POINT type
	//public Point  manipulatePoints()
	public Point[]  manipulatePoints()
	{
		//Point p = new Point();
		Point myPoints[] = new Point[10];
		/*myPoints[0] = new Point();
		myPoints[1] = new Point();*/
		for(int i=0;i<10;i++)
		{
			myPoints[i] = new Point(i+10,i+20);
		}
		return myPoints;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PointManipulator pointM = new PointManipulator();
		// Point x = pointM.manipulatePoints();
		// int y = pointM.manipulatePoints();
		// String z = pointM.manipulatePoints();
		//Employee e = new Employee()
		Point points[] =  pointM.manipulatePoints();
		/*
		 * points[0].displayCoordinates();
		 *  points[1].displayCoordinates();
		 *  --
		 *  --
		 */
		for(int i=0;i<points.length;i++)
		{
			points[i].displayCoordinates();
		}
	}

}
