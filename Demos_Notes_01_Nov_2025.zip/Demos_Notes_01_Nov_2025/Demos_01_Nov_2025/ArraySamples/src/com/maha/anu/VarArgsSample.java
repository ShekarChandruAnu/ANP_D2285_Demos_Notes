package com.maha.anu;

public class VarArgsSample {

	//Var Args are internally a Dynamic Array
	public void calculateAverageScore(String studName,String course,int... scores)// 3 4
	{
		//78 89 90
		int length = scores.length;
		int sum=0;
		for(int i=0;i<length;i++)
		{
			sum = sum+scores[i]; // sum = 0+78 --> sum = 78+89 -->sum = 167+90
		}
		double avgScore = sum/length;
		System.out.println("The Student :"+studName);
		System.out.println("Has Taken up The Course "+course);
		System.out.println("And his average score is "+avgScore);
		System.out.println("--------------");
	}
	public void checkCitiesTravelled(int empId,String empName,String... cities)
	{
		System.out.println("The Employee "+empName+" With an ID "+empId+"Has Travelled to the following cities");
		for(int i=0;i<cities.length;i++)
		{
			System.out.println(cities[i]);
		}
		System.out.println("----------");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarArgsSample vars = new VarArgsSample();
		/*vars.calculateAverageScore("Harshitha", "MCA", 89,78,67,75);
		vars.calculateAverageScore("Sumitha", "BCA", 69,78);
		vars.calculateAverageScore("Ranjan", "MCA", 69,78,90,92,93,94);
		vars.calculateAverageScore("Keerthana", "MCA", 69,78,87);*/
		System.out.println("-------");
		vars.checkCitiesTravelled(100, "Kiran Kumar", "NewYork","London","Chennai","Sydney","Bangalore","Mangalore");
		vars.checkCitiesTravelled(101, "Rajendra Kumar", "Chennai","Hyderabad","Bangalore");
		vars.checkCitiesTravelled(102, "Rajesh Kumar", "Melbourne","Paris","Chennai","Sydney","Bangalore");
		vars.checkCitiesTravelled(102, "Rakesh Kumar");
		
	}

}
