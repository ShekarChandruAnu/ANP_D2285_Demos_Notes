package com.mahatumku.anu;

import java.util.ArrayList;

// BOXING UNBOXING
public class ArrayListSample {
 ArrayList myList = new ArrayList();
 // typeOf() GENERICS - GIVEN CONTEXT <T> <Customer>  <Employee>
 public void manipulateArrayList()
 {
	 myList.add(20000);
	 myList.add("Hello World");
	 myList.add(23456.56);
	 myList.add(282929299.353636);
	 myList.add(true);
	 //For each loop
	 for(Object o : myList)
	 {
		 System.out.println("The data in Object form "+o);
	 }
	 //For
	 
	 //Iterator
 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListSample als = new ArrayListSample();
		als.manipulateArrayList();

	}

}
