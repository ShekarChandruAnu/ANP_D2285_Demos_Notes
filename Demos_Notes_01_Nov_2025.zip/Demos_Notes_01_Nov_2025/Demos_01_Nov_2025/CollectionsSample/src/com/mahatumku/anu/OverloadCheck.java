package com.mahatumku.anu;

public class OverloadCheck {

	public void add(int a,int b,int c)
	{
		
	}
	public void add(int a,int b,float c)
	{
		
	}
	public void add(String a,String b,int c)
	{
		
	}
	public void add(String a,float b,int c)
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
