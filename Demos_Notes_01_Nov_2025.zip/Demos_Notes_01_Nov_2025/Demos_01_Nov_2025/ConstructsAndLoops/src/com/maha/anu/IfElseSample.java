package com.maha.anu;

public class IfElseSample {

	public void checkIfElse(int score)
	{
		if((score >= 0) && (score <=100))
		{
			if((score >= 50) && (score < 60))
			{
				System.out.println("Good Passed!!!");
			}
			else if ((score >= 60) && (score < 70))
			{
				System.out.println("V Good Secured First Class...");
			}
			else if((score >= 70) && (score <= 100))
			{
				System.out.println("Excellent Secured Distincition....");
			}
			else
			{
				System.out.println("Sorry Try Again.....");
			}
		}
		else
		{
			System.out.println("Sorry Valid Score is 0-100");
		}
	}
	public void checkSwitch(int day)
	{
		// int char String
		switch(day)
		{
			case 1:
			{
				System.out.println("The Day is Monday ...");
				break;
			}
			case 2:
			{
				System.out.println("The Day is Tuesday ...");
				break;
			}
			case 3:
			{
				System.out.println("The Day is Wednesday ...");
				break;
			}
			case 4:
			{
				System.out.println("The Day is Thursday ...");
				break;
			}
			case 5:
			{
				System.out.println("The Day is Friday ...");
				break;
			}
			case 6:
			{
				System.out.println("The Day is Saturday ...");
				break;
			}
			case 7:
			{
				System.out.println("The Day is Sunday ...");
				break;
			}
			default:
			{
				System.out.println("Sorry TheValid Range is 1-7");
				break;
			}
				
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IfElseSample ifelse = new IfElseSample();
	/*	ifelse.checkIfElse(45);
		ifelse.checkIfElse(55);
		ifelse.checkIfElse(65);
		ifelse.checkIfElse(75);
		ifelse.checkIfElse(145);
		ifelse.checkIfElse(-145);*/
		ifelse.checkSwitch(5);
		ifelse.checkSwitch(4);
		ifelse.checkSwitch(3);
		ifelse.checkSwitch(1);
		ifelse.checkSwitch(125);
		

	}

}
