package com.maha.anu1;

public class ArrayIndexOutExceptionSample {

	public void manipulateArray()
	{
		int arr[] = new int[10];
		System.out.println("We are Manipulating array....");
		for(int i=0;i<=10;i++)
		{
			try
			{
				arr[i] = (i+1)*100;
				System.out.println("Array Element is "+arr[i]);
			}
			catch(ArrayIndexOutOfBoundsException aie)
			{
				aie.printStackTrace();
			}
			
		}
		System.out.println("We finished Array Manipulation...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are in Main about to Manipulate Array...");
		ArrayIndexOutExceptionSample aix = new ArrayIndexOutExceptionSample();
	/*	try
		{*/
			aix.manipulateArray();
	/*	}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}*/
		System.out.println("We finished Array Manipulation ... exiting Main...");

	}

}
