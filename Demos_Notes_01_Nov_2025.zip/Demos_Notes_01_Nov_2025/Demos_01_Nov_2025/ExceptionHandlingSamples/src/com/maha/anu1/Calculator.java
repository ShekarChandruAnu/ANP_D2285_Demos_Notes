package com.maha.anu1;

public class Calculator {
	
	public void calculate(int num1,int num2)
	{
		int result =0;
		System.out.println("We are in the Calculator Method...");
		System.out.println("We are about to calculate...");
		try
		{
			//INITIALIZTION
			result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		// A BLOCK WHICH WOULD BE EXECUTED IRRESPECTIVE OF WHETHER EXCEPTION WAS THROWN OR NOT
		finally
		{
			System.out.println("Closing Up Of Resources");
		}
		System.out.println("The Dividend is "+result);
		System.out.println("We are exiting the Calculator Method...");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator calci1 = new Calculator();
		System.out.println("We are in Main...abt to call Calculate Method");
	/*	try
		{*/
			calci1.calculate(100, 25);
			calci1.calculate(50, 10);
			calci1.calculate(100, 0);
			calci1.calculate(25, 5);
			calci1.calculate(100, 10);
	/*	}
		catch(ArithmeticException ae)
		{
			System.out.println("Exception :"+ae.getMessage());
			ae.printStackTrace();
		}*/
		System.out.println("We finished calculation ...");
		System.out.println("Exiting Main..");

	}

}
