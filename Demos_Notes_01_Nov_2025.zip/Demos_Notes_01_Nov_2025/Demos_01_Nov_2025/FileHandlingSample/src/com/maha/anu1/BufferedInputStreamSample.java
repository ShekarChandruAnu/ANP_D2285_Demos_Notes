package com.maha.anu1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamSample {

	BufferedInputStream bis;
	byte[] mybytes = new byte[100];
	public void readFromBinaryStreamThruBuffer()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream("supplier.txt"),100000);
			bis.read(mybytes);
			bis.close();
			String str = new String(mybytes);
			System.out.println("The Data Read from Binary STream based file thru Buffer is "+str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamSample biss = new BufferedInputStreamSample();
		biss.readFromBinaryStreamThruBuffer();
	}

}
