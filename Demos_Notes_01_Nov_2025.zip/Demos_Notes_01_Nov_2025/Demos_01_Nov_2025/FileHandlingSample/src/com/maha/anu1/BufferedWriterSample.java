package com.maha.anu1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterSample {

	BufferedWriter bw;
	//FileWriter fw;
	String str = "We are writing Dealers info into Char Stream through Buffered Writer";
	public void writeToCharStreamThruBuffer()
	{
		try {
		//	fw = new FileWriter("dealer.txt");
			bw = new BufferedWriter(new FileWriter("dealer.txt"));
			bw.write(str);
			bw.flush();
			bw.close();
			System.out.println("We have written char data into Char STream thru Buffer successfully...");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedWriterSample bws = new BufferedWriterSample();
		bws.writeToCharStreamThruBuffer();

	}

}
