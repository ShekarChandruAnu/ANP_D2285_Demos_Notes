package com.maha.anu2;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedInputStreamFroKeyBoard {

	BufferedInputStream bis;
	byte[] mybytes = new byte[100];
	public void readFromKeyBoardThruBuffer()
	{
		bis = new BufferedInputStream(System.in);
		System.out.println("Enter the data i.e to be Read thru Buffer....");
		try {
			bis.read(mybytes);
			bis.close();
			String str = new String(mybytes);
			System.out.println("The Data Read through Buffer from KeyBoarD is :"+str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamFroKeyBoard bisk = new BufferedInputStreamFroKeyBoard();
		bisk.readFromKeyBoardThruBuffer();

	}

}
