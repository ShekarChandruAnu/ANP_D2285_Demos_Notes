package com.maha.anu3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutInputStreamSample {

	DataOutputStream dos;
	DataInputStream dis;
	public void writeToDataOutputStream()
	{
		try {
			dos = new DataOutputStream(new FileOutputStream("products.txt"));
			dos.writeUTF("Hello World");
			dos.writeBoolean(true);
			dos.writeLong(373883839399L);
			dos.writeInt(102020);
			dos.writeFloat(123.455f);
			dos.writeDouble(123445.67d);
			dos.flush();
			dos.close();
			System.out.println("We have written originally typed data into Streams using DataOutputStream...");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}	
	public void readFromDataOutputStream()
	{
		try {
			dis = new DataInputStream(new FileInputStream("products.txt"));
			System.out.println("The Data Read in its original types..");
			
			System.out.println("The String Data Read "+dis.readUTF());
			System.out.println("The Boolean Data Read :"+dis.readBoolean());
			System.out.println("The Long Data Read :"+dis.readLong());
			System.out.println("The Int Data Read :"+dis.readInt());
			System.out.println("The Float Data Read "+dis.readFloat());
			System.out.println("The Double Data Read "+dis.readDouble());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	DataOutInputStreamSample dois = new DataOutInputStreamSample();
		dois.writeToDataOutputStream();*/
		DataOutInputStreamSample dois = new DataOutInputStreamSample();
		dois.readFromDataOutputStream();
		

	}

}
