package com.maha.anu;

public class NonFinalClass {

	 final static int FINAL_GRACE = 10;
	 final  int FINAL_BONUS = 15;
	public void nonFinalMethod()
	{
		// FINAL_GRACE = 11; //NOT ALLOWED
		// FINAL_BONUS = 16; NOT ALLOWED
		System.out.println("Non Final Method in Non Final Class.....");
		System.out.println("Final Bonus is "+FINAL_BONUS);
		System.out.println("Final Grace is "+FINAL_GRACE);
	}
	public  final void finalMethod()
	{
		System.out.println("This Method is Final....cannot be overridden");
	}
	
	/*
	public static void main(String[] args)
	{
		
	}*/

}
class MyDerivedNonFinalClass extends NonFinalClass
{
	@Override
	public void nonFinalMethod()
	{
		System.out.println(" Allows Overriding of Non Final Method ");
	}
/*	@Override
	public static void main(String[] args)
	{
		
	}*/
	
	/* Not allowed to override a Final Method
	@Override
	public  void finalMethod()
	{
		
	}*/
}
