package com.maha.anu;

import java.util.Scanner;

public class Furniture {
	
	protected int length;
	protected int width;
	protected int height;
	protected Scanner scan1;

	//Ctrl+SHift+O (not zero) 
	//Default Constructor - 0 to int null to string 0.0 
	
	public Furniture()
	{
		length = 0;
		width = 0;
		height = 0;
		scan1 = new Scanner(System.in);
	}
	// MIIRRORING
	public Furniture(int length,int width,int height)
	{
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public void acceptFurnitureDetails()
	{
		System.out.println("Enter the Furniture Details...");
		System.out.println("Enter the Length ");
		length = scan1.nextInt();
		System.out.println("Enter the Width ");
		width = scan1.nextInt();
		System.out.println("Enter the Height ");
		height = scan1.nextInt();
	}
	public void displayFurnitureDetails()
	{
		System.out.println("The Furniture Details are..");
		System.out.println("The Length is "+length);
		System.out.println("The Width is "+length);
		System.out.println("The height is "+height);
	}

}
