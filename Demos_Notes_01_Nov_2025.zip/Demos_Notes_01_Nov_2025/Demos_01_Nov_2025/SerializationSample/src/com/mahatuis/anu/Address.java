package com.mahatuis.anu;

import java.io.Serializable;

public class Address implements Serializable{

	String dNo;
transient String street;
	String area;
	String city;
transient int zip;
	
	public Address() {
		super();
	}
// this is an instance of current class
	public Address(String dNo, String street, String area, String city, int zip) {
		super();
		this.dNo = dNo;
		this.street = street;
		this.area = area;
		this.city = city;
		this.zip = zip;
	}

	public String getdNo() {
		return dNo;
	}

	public void setdNo(String dNo) {
		this.dNo = dNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Address [dNo=" + dNo + ", street=" + street + ", area=" + area + ", city=" + city + ", zip=" + zip
				+ "]";
	}
	
	
	
}
