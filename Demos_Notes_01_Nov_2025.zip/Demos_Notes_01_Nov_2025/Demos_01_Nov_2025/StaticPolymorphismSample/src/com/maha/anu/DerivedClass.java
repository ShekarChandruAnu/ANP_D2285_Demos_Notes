package com.maha.anu;

public class DerivedClass extends BaseClass {

	public void display2()
	{
		System.out.println("Displaying Derived Class Method ....");
	}
	
	@Override
	public void display()
	{
		System.out.println("Displaying Plain Display method of Derived class");
	}
}
