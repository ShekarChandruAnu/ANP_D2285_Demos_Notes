//All Classes in Java are inherited from Object
//Object class belongs to java.lang
/*
 * public int toString()
 * {
 * 	return this.hashCode()
 * }
 * 
 * 
 */

public class Student /*extends Object*/{
	
	private String studentId;
	private String studentName;
	private String studentCourse;
	private int score;
	
	public Student()
	{
		
	}
	public Student(String studentId,String studentName,String studentCourse,int score)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentCourse = studentCourse;
		this.score = score;
	}
	
	public void setStudentId(String studentId)
	{
		this.studentId = studentId;
	}
	public String getStudentId()
	{
		return this.studentId;
	}
	
	public void setStudentName(String studentName)
	{
		this.studentName = studentName;
	}
	public String getStudentName()
	{
		return this.studentName;
	}
	public void setScore(int score)      
	{   
		this.score=score;   
	}
	public int getScore()   
	{ 
		return this.score;  
	}
	
	public void setStudentCourse(String studentCourse)
	{
		this.studentCourse = studentCourse;
	}
	public String getStudentCourse()
	{
		return this.studentCourse;
	}
	public void displayStudentDetails()
	{
		System.out.println("------Student Details are-----");
		System.out.println("Student Id "+studentId);
		System.out.println("Student Name "+studentName);
		System.out.println("Student Course "+studentCourse);
		System.out.println("Student Score "+score);
	}
	@Override
	public String toString()
	{
		String studStr = "Student "+studentName+" With an Id "+studentId+" Has taken up a Course "+studentCourse+" and Has Secured an Average score of "+score;
		return studStr;
	}/**/

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1 = new Student("S001","Harshita","MCA",80);
		System.out.println("------------Student Details are -------------");
		System.out.println("Student Id :"+student1.getStudentId());
		System.out.println("Student Name :"+student1.getStudentName());
		System.out.println("Student Course :"+student1.getStudentCourse());
		System.out.println("Student Score :"+student1.getScore());
System.out.println("------------Student Details displayed after initializing through Setters -------------");
		Student student2 = new Student();
		student2.setStudentId("S002");
		student2.setStudentName("Rekha");
		student2.setStudentCourse("MCA");
		student2.setScore(84);
		
		student2.displayStudentDetails();
		System.out.println("Student Details "+student2);
		System.out.println("Student Details "+student1);
		
		
		//toString()
	}

}
