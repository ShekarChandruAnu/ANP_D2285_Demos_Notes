package com.maha.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//Creating Class
				// Encapsulating Data Members & Methods
				// We saw Access Modifiers
				//Creating an Object of  a Class
				//Invoking Methods of a Class using Objects
				// Explicit Initialization of Data Members and which was Invoked explicitly
		Employee employee1 = new Employee(); // INVOKES DEFAULT CONSTRUCTOR EXPLICITLY CREATED BY US
	//	employee1.initializeData();
		employee1.displayEmployeeDetails();
		System.out.println("------DISPLAY DUE TO OVERLOADED CONSTRUCTOR INITIALIZATION-----");
		Employee employee2 = new Employee("E002","Kirtan Kumar","Malleswaram","9738383883",12000,12.34f);
		employee2.displayEmployeeDetails();
		System.out.println("------DISPLAY DUE TO OVERLOADED CONSTRUCTOR INITIALIZATION with 4 params-----");
		Employee employee3 = new Employee("E003","Harish Kumar","Koramangala","8399393993");
		employee3.displayEmployeeDetails();
		System.out.println("------DISPLAY DUE TO OVERLOADED CONSTRUCTOR INITIALIZATION with 3 params-----");
		Employee employee4 = new Employee("E004","Keerthana","Vijayanagar");
		employee4.displayEmployeeDetails();
		
	}

}
