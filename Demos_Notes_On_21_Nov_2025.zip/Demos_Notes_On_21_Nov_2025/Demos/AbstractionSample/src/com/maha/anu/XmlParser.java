package com.maha.anu;

public class XmlParser extends Parser{

	@Override
	public void parse(String fileType) {
		// TODO Auto-generated method stub
		System.out.println("Parsing The File Type XML"+fileType);
	}

}
