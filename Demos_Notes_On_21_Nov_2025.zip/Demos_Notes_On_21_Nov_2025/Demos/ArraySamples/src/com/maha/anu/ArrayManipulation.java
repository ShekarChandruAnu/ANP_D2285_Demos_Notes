package com.maha.anu;

public class ArrayManipulation {

	public void manipulate1DArray()
	{
		int arr[] = new int[10];
		for(int i=0;i<10;i++)
		{
			arr[i]=(i+1)*100;
			System.out.print(arr[i]+" ");
		}
	}
	public void manipulate2DArray()
	{
		int arr[][] = new int[3][4];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr[i][j] = (i+j)*100;
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayManipulation aManip = new ArrayManipulation();
	//	aManip.manipulate1DArray();
		aManip.manipulate2DArray();
	}

}
