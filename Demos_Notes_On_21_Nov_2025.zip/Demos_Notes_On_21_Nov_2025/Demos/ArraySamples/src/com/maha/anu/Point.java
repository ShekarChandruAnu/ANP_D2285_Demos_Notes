package com.maha.anu;

public class Point {
	
	int xCoord,yCoord;

	public Point() {
		super();
	}

	public Point(int xCoord, int yCoord) {
		super();
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}

	public int getxCoord() {
		return xCoord;
	}

	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}

	public int getyCoord() {
		return yCoord;
	}

	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}
	
	public void displayCoordinates()
	{
		System.out.println("The X Coordinate is "+xCoord+" Y Coordinate is "+yCoord);
	}

}
