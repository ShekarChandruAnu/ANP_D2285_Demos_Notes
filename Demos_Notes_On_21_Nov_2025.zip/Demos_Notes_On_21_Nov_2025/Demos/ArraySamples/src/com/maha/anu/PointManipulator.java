package com.maha.anu;

public class PointManipulator {

	//This method returns an Array of Objects of POINT type
	//public Point  manipulatePoints()
	/*
	 *  public int getScore() { int x  = 56; return x;}
	 *  public int[] getScores()
	 *  {
	 *  	int arr[] = new int[3]; arr[0] = 100;arr[1] = 110;arr[2] = 120;
	 *  	or
	 *  	int arr[] = new int[]{ 100,200,300};
	 *  	return arr;
	 *  }
	 *  public Employee getEmployee()
	 *  {
	 *  Employee e1 = new Employee(,,,,,,);
	 *  
	 *  	return e1;
	 *  }
	 *  public Employee[] getAllEmployees()
	 *  {
	 *  Employee emp[] = new Employee[2];
	 *  emp[0] = new Employee("E001","Harsha",10000);
	 *  emp[1] = new  Employee("E002","SreeHarsha",12000);
	 *  
	 *  
	 *  
	 *  return emp;
	 *  }
	 */
	public Point[]  manipulatePoints()
	{
		//Point p = new Point();
		Point myPoints[] = new Point[10];
		/*myPoints[0] = new Point();
		myPoints[1] = new Point();*/
		for(int i=0;i<10;i++)
		{
			myPoints[i] = new Point(i+10,i+20);
		}
		return myPoints;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PointManipulator pointM = new PointManipulator();
		// Point x = pointM.manipulatePoints();
		// int y = pointM.manipulatePoints();
		// String z = pointM.manipulatePoints();
		//Employee e = new Employee()
		Point[] points =  pointM.manipulatePoints();
		/*
		 * points[0].displayCoordinates();
		 *  points[1].displayCoordinates();
		 *  --
		 *  --
		 */
		for(int i=0;i<points.length;i++)  //for(Point x:points){ x.displayCoordinates();}
		{
			points[i].displayCoordinates();
		}
	}

}
