package com.mahatumku.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class EmployeeArrayList {

	ArrayList employeeList = new ArrayList();
	public void manipulateArrayList()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		employeeList.add(e1);
		employeeList.add(new Employee("E002","Mahesh","JayaNagar","7652993939",14000));
		employeeList.add(new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000));
		employeeList.add(new Employee("E004","Maheshwari","Malleswaram","7656893939",18000));
		employeeList.add(new Employee("E005","Rajesh","JayaNagar","7652996789",22000));
		employeeList.add(new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
	}
	public void displayArrayList()
	{
		System.out.println(employeeList);
		System.out.println("----------Fast Enumeration----------");
		for(Object o:employeeList)
		{
			System.out.println((Employee)o);
		}
		System.out.println("-------Using Iterator --------");
		Iterator empIter = employeeList.iterator();
		while(empIter.hasNext())
		{
			Employee e = (Employee) empIter.next();
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeArrayList eal = new EmployeeArrayList();
		eal.manipulateArrayList();
		eal.displayArrayList();

	}

}
