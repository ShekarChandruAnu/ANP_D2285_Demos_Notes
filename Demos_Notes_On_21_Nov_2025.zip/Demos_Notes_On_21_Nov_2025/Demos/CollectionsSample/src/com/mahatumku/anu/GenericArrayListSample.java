package com.mahatumku.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayListSample {

	//ArrayList <Employee> empAList = new ArrayList<>();
	ArrayList <Employee> empAList = new ArrayList<Employee>();
	public void manipulateArrayList()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		empAList.add(e1);
		empAList.add(new Employee("E002","Mahesh","JayaNagar","7652993939",14000));
		empAList.add(new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000));
		empAList.add(new Employee("E004","Maheshwari","Malleswaram","7656893939",18000));
		empAList.add(new Employee("E005","Rajesh","JayaNagar","7652996789",22000));
		empAList.add(new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
		
		//empAList.add("Hello");
	}
	public void displayArrayList()
	{
		Iterator <Employee> empIter = empAList.iterator();
		while(empIter.hasNext())
		{
			Employee e= empIter.next();
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GenericArrayListSample gal = new GenericArrayListSample();
		gal.manipulateArrayList();
		gal.displayArrayList();
	}

}
