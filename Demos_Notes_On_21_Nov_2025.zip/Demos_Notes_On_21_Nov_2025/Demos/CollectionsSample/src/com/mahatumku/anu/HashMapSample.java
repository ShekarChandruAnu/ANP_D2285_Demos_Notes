package com.mahatumku.anu;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapSample {

	//NOT SYNCHRONIZED - Keys Not Sorted - Keys Unique
	HashMap <String,Employee> employeeMap = new HashMap<String,Employee>();
	
	public void populateHashMap()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		Employee e2 =new Employee("E002","Mahesh","JayaNagar","7652993939",14000);
		Employee e3 =new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000);
		Employee e4 =new Employee("E004","Maheshwari","Malleswaram","7656893939",18000);
		Employee e5 =new Employee("E005","Rajesh","JayaNagar","7652996789",22000);
		Employee e6 =new Employee("E006","Rakesh","Malleswaram","7321993939",21000);
		
		employeeMap.put("E001",e1);
		employeeMap.put("E002",e2);
		employeeMap.put("E003",e3);
		employeeMap.put("E004",e4);
		employeeMap.put("E005",e5);
		employeeMap.put("E006",e6);
		employeeMap.put("E006",e5);
	}
	public void fetchHashMapData()
	{
		// employeeMap.values();
		Set <String> myKeys = employeeMap.keySet();
		Iterator <String> keyIter = myKeys.iterator();
		while(keyIter.hasNext())
		{
			String myKey = keyIter.next();
			System.out.println("The Value for the Key "+myKey+" is "+employeeMap.get(myKey));
		}
		
	}
	public void fetchHashMapThruEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = employeeMap.entrySet();
		Iterator <Entry <String,Employee>> myEntryIter = myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntryIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" And corresponding Value is "+myEntry.getValue());
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		//hms.fetchHashMapData();
		hms.fetchHashMapThruEntrySet();

	}

}
