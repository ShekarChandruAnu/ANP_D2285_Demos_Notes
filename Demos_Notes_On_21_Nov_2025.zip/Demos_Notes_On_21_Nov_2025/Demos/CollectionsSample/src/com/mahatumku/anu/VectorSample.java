package com.mahatumku.anu;

import java.util.Enumeration;
import java.util.Vector;

public class VectorSample {

	Vector <Employee> empVector = new Vector<Employee>(5,2);
	public void populateVectorUsingAddElement()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		Employee e2 =new Employee("E002","Mahesh","JayaNagar","7652993939",14000);
		Employee e3 =new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000);
		Employee e4 =new Employee("E004","Maheshwari","Malleswaram","7656893939",18000);
		Employee e5 =new Employee("E005","Rajesh","JayaNagar","7652996789",22000);
		Employee e6 =new Employee("E006","Rakesh","Malleswaram","7321993939",21000);
		Employee e7 =new Employee("E007","Ramesh","Malleswaram","7321945939",22000);
		Employee e8 =new Employee("E008","RameshK","Malleswaram","7321445939",22000);
		Employee e9 =new Employee("E009","RameshL","Malleswaram","7321345939",22000);
		System.out.println("The Capacity now  is "+empVector.capacity());
		empVector.addElement(e1);
		empVector.addElement(e2);
		empVector.addElement(e3);
		empVector.addElement(e4);
		System.out.println("The Capacity now  is "+empVector.capacity());
		empVector.addElement(e5);
		System.out.println("The Capacity now  is "+empVector.capacity());
		empVector.addElement(e6);
		System.out.println("The Capacity now  is "+empVector.capacity());
		System.out.println("The current Size is "+empVector.size());
		empVector.addElement(e7);
		empVector.addElement(e8);
		empVector.addElement(e9);
		System.out.println("The Capacity now  is "+empVector.capacity());
	}
	public void fetchVectorDataUsingEnumeration()
	{
		Enumeration <Employee> empVectorEnumer = empVector.elements();
		
		while(empVectorEnumer.hasMoreElements())
		{
			Employee employee = empVectorEnumer.nextElement();
			System.out.println(employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VectorSample vSample = new VectorSample();
		vSample.populateVectorUsingAddElement();
		vSample.fetchVectorDataUsingEnumeration();

	}

}
