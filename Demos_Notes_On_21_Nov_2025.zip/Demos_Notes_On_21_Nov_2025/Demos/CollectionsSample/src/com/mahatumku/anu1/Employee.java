package com.mahatumku.anu1;

public class Employee implements Comparable <Employee> {

	String empId;
	String empName;
	String empAddress;
	String empPhone;
	int empSalary;
	
	public Employee() {
		super();
	}

	public Employee(String empId, String empName, String empAddress, String empPhone, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
		this.empSalary = empSalary;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + ", empPhone="
				+ empPhone + ", empSalary=" + empSalary + "]";
	}
	/*

	String str1 = "Hyderabad";
	String str2 = "hyderabad";
	str1.compareTo(str2) 0 >0 <0
	*/
	/*
	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if(this.getEmpId().compareTo(employee.getEmpId()) > 0)
		{
			return 1;
		} 
		else if(this.getEmpId().compareTo(employee.getEmpId()) < 0 )
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if(this.getEmpName().compareTo(employee.getEmpName()) > 0)
		{
			return -1;
		} 
		else if(this.getEmpName().compareTo(employee.getEmpName()) < 0 )
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}	*/				//	chandu babu 

	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if(this.getEmpSalary() > employee.getEmpSalary() )
		{
			return 1;
		}
		else if (this.getEmpSalary() < employee.getEmpSalary() )
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	

	
	
	
	
}
