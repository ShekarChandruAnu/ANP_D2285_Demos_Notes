package com.mahatumku.anu1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList <Employee> empList = new ArrayList<Employee>(); 
		empList.add(new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
		empList.add(new Employee("E004","Maheshwari","Malleswaram","7656893939",18000));
		empList.add(new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000));
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		empList.add(e1);
		empList.add(new Employee("E002","Mahesh","JayaNagar","7652993939",14000));
		empList.add(new Employee("E005","Rajesh","JayaNagar","7652996789",22000));
		
		Collections.sort(empList);
		Iterator <Employee> empIter = empList.iterator();
		
		
	/*	System.out.println("----------Sorting Based on ID ------");
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}
		
		System.out.println("----------Sorting Based on Name ------");
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}*/
		System.out.println("----------Sorting Based on Salary ------");
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}
	
		
		//FUNCTIONAL PROGRAMMING
	}

}
