package com.mahatumku.anu3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class StudentSorter {

	public static void main(String[] args) {
		
		Queue <String> myQueue = new PriorityQueue();
		Deque <String> myDeque = new ArrayDeque();		
		
		
		
		// TODO Auto-generated method stub
		Student stud3 = new Student("S003","Emanuel","Faridabad",87);
		Student stud1 = new Student("S001","Chandu","Gandhinagar",67);
		Student stud5 = new Student("S005","Aravind","Ernakulam",77);
		Student stud2 = new Student("S002","Ganesh","Ahmedabad",57);
		Student stud4 = new Student("S004","Farheen","Bangalore",82);
		
		ArrayList <Student> studList = new ArrayList<Student>();
		studList.add(stud3);
		studList.add(stud1);
		studList.add(stud5);
		studList.add(stud2);
		studList.add(stud4);
		System.out.println("-----------Students Sorted based on ID ------------");
		Collections.sort(studList, new StudIdSorter());
		Iterator <Student> studIdIter = studList.iterator();
		while(studIdIter.hasNext())
		{
			System.out.println(studIdIter.next());
		}
		
		System.out.println("-----------Students Sorted based on Student City ------------");
		Collections.sort(studList,new StudCitySorter());
		Iterator <Student> studCityIter = studList.iterator();
		while(studCityIter.hasNext())
		{
			System.out.println(studCityIter.next());
		}
		System.out.println("-----------Students Sorted based on Student Score ------------");
		Collections.sort(studList,new StudScoreSorter());
		Iterator <Student> studScoreIter = studList.iterator();
		while(studScoreIter.hasNext())
		{
			System.out.println(studScoreIter.next());
		}
	}

}
