package com.maha.anu;

import java.util.Scanner;

public class LoopSample {

	//System.out.println()
	Scanner scan1 = new Scanner(System.in);
	public void checkWhiler()
	{
		String reply = "Yes";
		while(reply.equals("Yes") || reply.equals("yes") || reply.equals("YES"))
		{
			int num;
			int sqr;
			System.out.println("Enter a Number.....");
			num = scan1.nextInt();
			sqr = num * num;
			System.out.println("The Square of your Number "+num+"  is :"+sqr);
			System.out.println("Do You wish to Continue yes/no");
			reply = scan1.next();
			
		}
			System.out.println("We are Out of Loop....");
	}
	public void checkDoWhiler()
	{
		String reply = "Yes";
		do
		{
			int num;
			int sqr;
			System.out.println("Enter a Number.....");
			num = scan1.nextInt();
				if(num > 100)
				{
					System.out.println("Sorry Number to be less than or equal to 100");
					continue;
				}
			sqr = num * num;
			System.out.println("The Square of your Number "+num+"  is :"+sqr);
			System.out.println("Do You wish to Continue yes/no");
			reply = scan1.next();
			
		}while(reply.equals("Yes") || reply.equals("yes") || reply.equals("YES"));
			System.out.println("We are Out of Loop....");
	}
	public void checkFor()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("The Value is "+(i+1));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoopSample lSamp = new LoopSample();
		//lSamp.checkWhiler();
		//lSamp.checkDoWhiler();
		lSamp.checkFor();
	}

}
