package com.maha.anu2;

public class Recruitment {
	
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}
		
	}
	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("Recruitment ..Age Scrutinization started.");
		if(age < 20 || age > 30)
		{
			/*InvalidAgeException iae = new InvalidAgeException("SOrry Invalid Age, Valid Age to be 20-30");
			throw iae;*/
			// ANONYMOUS OBJECT
			throw new InvalidAgeException("SOrry Invalid Age, Valid Age to be 20-30");
		}
		System.out.println("Valid Age "+age);
		System.out.println("Age Scrutiny completed proceed with the remai ning Recruitment Process");
	}
	
	public static void main(String[] args)
	{
		System.out.println("Recruitment Process Started ....");
		Recruitment rc = new Recruitment();
		/*try
		{*/
									//try
			rc.callCheckAge(24);	// {rc.checkAge(24)			
			rc.callCheckAge(23);   // rc.checkAge(23)	
			rc.callCheckAge(31);   // rc.checkAge(31)	
			rc.callCheckAge(21);   // rc.checkAge(21)	
			rc.callCheckAge(27);   // rc.checkAge(27)}	
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
		}*/
		
		System.out.println("Recruitment Process completed...");
	}

}
