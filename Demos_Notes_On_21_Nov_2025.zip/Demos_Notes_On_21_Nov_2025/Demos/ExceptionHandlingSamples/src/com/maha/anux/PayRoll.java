package com.maha.anux;

public class PayRoll {

	public void performPayRoll()
	{
		// Shapes sh = new Rectangle()
		//Recruitment rc = new Recruitment();
		Recruitment rc=null;
		
		
		/*
		 * 
		 * 
		 
		 */
		
		Employee e1 = rc.getEmployeeDetails();
		System.out.println(e1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PayRoll pr = new PayRoll();
		pr.performPayRoll();

	}

}
