package com.maha.anux;

public class Recruitment {

		public Employee getEmployeeDetails()
		{
			Employee e1 = new Employee("E001","Harsha");
			return e1;
		}
}
