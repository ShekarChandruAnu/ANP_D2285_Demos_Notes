package com.maha.anu;

public class BookShelf extends Furniture{

	int noOfShelves;
	
	public BookShelf()
	{
		noOfShelves = 0;
	}
	public BookShelf(int noOfShelves)
	{
		this.noOfShelves = noOfShelves;
	}
	public void acceptBookShelfDetails()
	{
		/*
		System.out.println("Enter the Length ");
		length = scan1.nextInt();
		System.out.println("Enter the width ");
		width = scan1.nextInt();
		System.out.println("Enter the Height ");
		height = scan1.nextInt();*/
		/*Furniture furn = new Furniture()*/
		//this : instance of the current class
		// super instance of the parent class
		super.acceptFurnitureDetails();
		//acceptFurnitureDetails();
		System.out.println("Enter the No Of Shelves");
		noOfShelves = scan1.nextInt();
		display();
		Table tab1 = new Table();
		tab1.calculateCost();
	}
	public void displayBookShelfDetails()
	{
		System.out.println("The BookShelf Details are...");
		System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);
		System.out.println("The No Of Shelves is "+noOfShelves);
	}
	public void display()
	{
		
	}
	
}
