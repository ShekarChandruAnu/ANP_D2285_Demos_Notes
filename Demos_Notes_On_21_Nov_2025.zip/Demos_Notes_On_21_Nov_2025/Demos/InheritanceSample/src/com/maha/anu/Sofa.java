package com.maha.anu;

public class Sofa extends Furniture {

}
