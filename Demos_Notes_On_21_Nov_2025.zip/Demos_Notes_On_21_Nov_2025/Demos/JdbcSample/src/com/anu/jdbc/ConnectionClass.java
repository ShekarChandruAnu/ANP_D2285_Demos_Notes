package com.anu.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionClass {

	Connection con;
	

	
	Connection getMyConnection()
	{
		
		String url = "jdbc:mysql://localhost:3306/maharanistum";
		String user = "root";
		String password = "MySQL_@123456";
		try {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		return con;
		
	}
}
