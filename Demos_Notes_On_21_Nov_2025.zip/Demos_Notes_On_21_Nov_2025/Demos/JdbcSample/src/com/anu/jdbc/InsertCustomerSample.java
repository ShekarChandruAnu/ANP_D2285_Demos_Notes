package com.anu.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertCustomerSample {

	Connection myCon;
	Statement stmt;
	PreparedStatement pstmt;
	
	public void insertCustomer(Customer customer)
	{
		ConnectionClass cc = new ConnectionClass();
		myCon = cc.getMyConnection();
		String query = "insert into Customers values(?,?,?,?)";
		try {
			pstmt = myCon.prepareStatement(query);
			pstmt.setString(1, customer.getCustId());
			pstmt.setString(2, customer.getCustName());
			pstmt.setString(3, customer.getCustAddress());
			pstmt.setString(4, customer.getCustPhone());
			pstmt.execute();
			System.out.println("Customer Record Inserted Successfully...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sorry Insertion Failed...");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InsertCustomerSample ics = new InsertCustomerSample();
		Customer customer = new Customer("C007","Sumanth","Vijayanagar","9494949949");
		ics.insertCustomer(customer);

	}

}
