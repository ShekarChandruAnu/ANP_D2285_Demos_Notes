package com.anu.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnectionSample {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con;
		Statement stmt;
		ResultSet rs;
		String url = "jdbc:mysql://localhost:3306/maharanistum";
		String user = "root";
		String password = "MySQL_@123456";
		try {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from customers");
			System.out.println(" Customer Id  CustomerName  CustomerAddress CustomerPhone");
			System.out.println("------------- ------------- ------------- -------------");
			while(rs.next())
			{
				System.out.println(rs.getString(1)+ "   "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		

	}

}
