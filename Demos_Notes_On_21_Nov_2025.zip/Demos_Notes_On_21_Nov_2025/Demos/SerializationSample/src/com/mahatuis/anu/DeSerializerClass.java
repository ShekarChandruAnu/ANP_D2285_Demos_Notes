package com.mahatuis.anu;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializerClass {

	ObjectInputStream ois;
	Employee myEmployees[] = new Employee[4];
	
	public DeSerializerClass()
	{
		Address addr1 = new Address();
		Address addr2 = new Address();
		Address addr3 = new Address();
		Address addr4 = new Address();	/* */			
		for(int i=0;i<4;i++)
		{
			myEmployees[i] = new Employee();
		}
		myEmployees[0].setAddress(addr1);
		myEmployees[1].setAddress(addr2);
		myEmployees[2].setAddress(addr3);
		myEmployees[3].setAddress(addr4);
	
	}
	public void deSerializeEmployees()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("employees.txt"));
			myEmployees  = (Employee[]) ois.readObject();
			System.out.println("The DeSerialized Objects are...");
			for(Employee emp: myEmployees)
			{
				System.out.println("Employee "+emp);
			}
			
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DeSerializerClass deSerCls = new DeSerializerClass();
		deSerCls.deSerializeEmployees();

	}

}
