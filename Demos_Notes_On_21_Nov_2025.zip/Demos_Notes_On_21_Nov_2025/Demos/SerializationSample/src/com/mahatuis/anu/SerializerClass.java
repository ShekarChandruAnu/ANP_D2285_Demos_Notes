package com.mahatuis.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializerClass {
	
	ObjectOutputStream ops;
	Employee employees[] = new Employee[4];
	
	public void serializeEmployees()
	{
		Address addr1 = new Address("22/3","Berlie Street","CottonPet","Bangalore",560001);
		Address addr2 = new Address("22/1","Shanthi Street","Koramangala","Mangalore",560001);
		Address addr3 = new Address("23/2","Clifton Street","Vijayanagar","Hubli",560001);
		Address addr4 = new Address("24/1","Venkateshwara Street","Jayanagar","Hyderabad",400001); /* */
		
		
		for(int i=0;i<4;i++)
		{
			employees[i] = new Employee();
		}
		employees[0] = new Employee("E001","Kiran Kumar",10000,addr1);
		employees[1] = new Employee("E002","Keerthana",12000,addr2);
		employees[2] = new Employee("E003","Suman Kumar",14000,addr3);
		employees[3] = new Employee("E004","Shree",16000,addr4);  
		/*
		employees[0] = new Employee("E001","Kiran Kumar",10000);
		employees[1] = new Employee("E002","Keerthana",12000);
		employees[2] = new Employee("E003","Suman Kumar",14000);
		employees[3] = new Employee("E004","Shree",16000); */
		try {
			ops = new ObjectOutputStream(new FileOutputStream("employees.txt"));
			ops.writeObject(employees);
			ops.flush();
			ops.close();
			System.out.println("We have serialized the Employee Objects....");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		SerializerClass sClass = new SerializerClass();
		sClass.serializeEmployees();
	}

}
