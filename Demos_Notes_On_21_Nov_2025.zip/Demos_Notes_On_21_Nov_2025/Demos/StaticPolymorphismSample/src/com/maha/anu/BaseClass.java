package com.maha.anu;

public class BaseClass {
	public void display1()
	{
		System.out.println("Displaying Base Class Method...");
	}
	public void display()
	{
		System.out.println("Displaying Plain Display method of Baseclass");
	}

}
