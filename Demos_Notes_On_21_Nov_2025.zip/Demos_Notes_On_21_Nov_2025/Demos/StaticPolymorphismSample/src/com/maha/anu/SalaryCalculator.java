package com.maha.anu;

public class SalaryCalculator {
	public void calculateSalary(int basic,int hra , int cca,int allowances)
	{
		int grossSalary = (basic + hra + cca + allowances);
		System.out.println("The Gross Salary  is "+grossSalary);
	}
	public void calculateSalary(int basic, int hra , int cca,int allowances, int deductions,String employeeName)
	{
		int grossSalary = (basic + hra + cca + allowances);
		int nettSalary = (basic + hra + cca + allowances) - deductions;
		System.out.println("The Nett Salary for "+employeeName+" is "+nettSalary + " ANd the Gross Salary is "+grossSalary);
	}
	public void calculateSalary(int basic, int hra , int cca,int allowances, int deductions,String employeeName,double bonusPrcntg)
	{
		int grossSalary = (basic + hra + cca + allowances);
		int nettSalary = (basic + hra + cca + allowances) - deductions;
		double bonus = (bonusPrcntg / 100 )* grossSalary;
		System.out.println("The Nett Salary for "+employeeName+" is "+nettSalary + " ANd the Gross Salary is "+grossSalary+" And the Bonus he is eleigible is "+bonus);
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SalaryCalculator sCalci1 = new SalaryCalculator();
		sCalci1.calculateSalary(10000, 250, 350, 1200,550,"Harsha G");
		System.out.println("--------");
		sCalci1.calculateSalary(12000, 350, 450, 1300);
		sCalci1.calculateSalary(12000, 350, 450, 1300,675,"Kiran ",23.0f);
		System.out.println("--------");
	}

}
