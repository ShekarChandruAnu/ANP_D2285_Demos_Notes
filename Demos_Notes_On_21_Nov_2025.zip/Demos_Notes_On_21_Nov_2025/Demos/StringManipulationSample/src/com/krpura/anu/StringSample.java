package com.krpura.anu;

public class StringSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "welcome to java Strings";
		System.out.println(str1);
		str1 = "Welcome Back to Java Strings";
		System.out.println(str1);
	}

}
