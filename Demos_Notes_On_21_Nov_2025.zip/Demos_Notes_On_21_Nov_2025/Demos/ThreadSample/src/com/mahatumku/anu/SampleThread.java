package com.mahatumku.anu;

public class SampleThread {
//PRIMARY THREAD  1- 10
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread thread = Thread.currentThread();
		System.out.println("Current Thread Before Name Change:"+thread);
		thread.setName("changedCurrentThread");
		
		System.out.println("Current Thread After Name Change :"+thread);
		
	}

}
