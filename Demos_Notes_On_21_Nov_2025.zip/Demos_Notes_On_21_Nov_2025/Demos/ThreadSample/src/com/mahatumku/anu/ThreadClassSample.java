package com.mahatumku.anu;
class ThreadClass extends Thread
{
	public ThreadClass()
	{
		start();
	}
	public void run()
	{
		System.out.println("Entering Child Thread....");
		System.out.println("In The Child Thread...");
		System.out.println("Exiting Child Thread...");
	}
}
public class ThreadClassSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread about to invoke Child Thread....");
		ThreadClass tc = new ThreadClass();
		System.out.println("Back In The Main Thread...Exiting main Thread");

	}

}
