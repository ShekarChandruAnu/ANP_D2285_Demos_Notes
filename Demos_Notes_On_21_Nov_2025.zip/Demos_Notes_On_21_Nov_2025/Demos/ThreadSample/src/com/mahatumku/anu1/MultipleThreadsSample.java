package com.mahatumku.anu1;
class MyThread1 implements Runnable
{
	Thread t1;
	String threadName;
	public MyThread1(String threadName)
	{
		this.threadName = threadName;
		t1 = new Thread(this,threadName); // "childThread"
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println(threadName+" Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class MultipleThreadsSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread... about to invoke Child Threads....");
		MyThread1 mt1 = new MyThread1("ChildThread 1 ");
		MyThread1 mt2 = new MyThread1("ChildThread 2 ");
		MyThread1 mt3 = new MyThread1("ChildThread 3 ");
		mt1.t1.start();
		mt2.t1.start();
		mt3.t1.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Exiting Main Thread");

	}

}
