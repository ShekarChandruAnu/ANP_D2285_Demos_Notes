package com.mahatumku.anu1;
class MyThread
{
	//SYNCHRONIZED METHOD
	public/*synchronized*/ void call()
	{
		System.out.println("Produced Goods");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Consumed Goods");
	}
}
class Thread1 extends Thread
{
	MyThread t1;
	public Thread1(MyThread t1)
	{
		this.t1 = t1;
		//start();
	}
	public void run()
	{
		//SYNCHRONIZED BLOCK
		synchronized(t1)
		{
			t1.call();
		}
		/*
		 * 
		 * 
		 */
	}
}
public class SynchronizationSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread mt1 = new MyThread();
		Thread1 th1 = new Thread1(mt1);
		Thread1 th2 = new Thread1(mt1);
		Thread1 th3 = new Thread1(mt1);
		th1.start();
		th2.start();
		th3.start();
		
	}

}
