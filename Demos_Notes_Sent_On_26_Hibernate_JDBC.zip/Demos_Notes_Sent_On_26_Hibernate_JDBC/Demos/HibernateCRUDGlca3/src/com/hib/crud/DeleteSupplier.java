package com.hib.crud;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hib.model.Supplier;

public class DeleteSupplier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	SessionFactory sFactory = new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Supplier.class)
									.buildSessionFactory();
	
	Session delSession = sFactory.getCurrentSession();
	int delId = 6;
	try
	{
			delSession.beginTransaction();
			Supplier supplierDel = delSession.get(Supplier.class,delId);
			delSession.delete(supplierDel);
			System.out.println("THe Supplier Record deleted successfully for Id "+delId);
			delSession.getTransaction().commit();
	}
	finally
	{
		sFactory.close();
	}

	}

}
