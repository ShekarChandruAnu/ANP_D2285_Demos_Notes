package com.hib.crud;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hib.model.Supplier;

public class InsertSupplier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory sFactory = new Configuration()
										.configure("hibernate.cfg.xml")
										.addAnnotatedClass(Supplier.class)
										.buildSessionFactory();
		
		Session mySession = sFactory.getCurrentSession();
		//Supplier supplier = new Supplier()
		try
		{
			mySession.beginTransaction();
			Supplier supplier6 = new Supplier("Raj Traders","Indiranagar",700000);
			Supplier supplier7 = new Supplier("KLN Traders","Malleswaram",800000);
			Supplier supplier8 = new Supplier("FS Traders","Chickpet",900000);
			
			mySession.save(supplier6);
			mySession.save(supplier7);
			mySession.save(supplier8);
			
			System.out.println("The Supplier Records Inserted successfully...");
			
			mySession.getTransaction().commit();
		}
		finally
		{
			sFactory.close();
		}
		

	}

}
