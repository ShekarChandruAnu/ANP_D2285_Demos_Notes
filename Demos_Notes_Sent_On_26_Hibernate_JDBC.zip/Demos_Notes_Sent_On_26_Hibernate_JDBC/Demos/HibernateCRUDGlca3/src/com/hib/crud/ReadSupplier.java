package com.hib.crud;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hib.model.Supplier;

public class ReadSupplier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	SessionFactory sFactory =	new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Supplier.class)
									.buildSessionFactory();
	Session readSession = sFactory.getCurrentSession();
	//Hibernate Query Language - createSqlQuery("select * from Suppliers")
	try
	{
		//select *n from suppliers
		readSession.beginTransaction();
		List <Supplier> mySuppliers =	readSession.createQuery("from Supplier").list();
		System.out.println("The Supplier Details are...");
		for(Supplier s:mySuppliers)
		{
			System.out.println(s);
		}
		readSession.getTransaction().commit();
	}
	finally
	{
		sFactory.close();
	}

	}

}
