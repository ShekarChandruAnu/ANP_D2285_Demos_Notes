package com.hib.crud;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hib.model.Supplier;

public class UpdateSupplier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	SessionFactory sFactory = new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Supplier.class)
									.buildSessionFactory();
	Session updateSession = sFactory.getCurrentSession();
	Supplier supplier = new Supplier(); // Object is in Transient still not associated with session
	try
	{
		updateSession.beginTransaction();
		//Fetching the record for the object(record) belonging to a Class Supplier whose Id = 5
		 supplier = updateSession.get(Supplier.class,5);
		
		supplier.setSupplierAddress("NagarathPet");
		supplier.setSupplyValue(900000);
		System.out.println("The Supplier Recor is updated");
		//ALl the changes affected to the PERSISTENT OBJECT WHICH IS IN THE
		//SESSION WILL GET UPDTED IN THE DATABASE
		//WHEN COMMITTED
		updateSession.getTransaction().commit();
	}
	finally
	{
		sFactory.close();
	}
	

	}

}
