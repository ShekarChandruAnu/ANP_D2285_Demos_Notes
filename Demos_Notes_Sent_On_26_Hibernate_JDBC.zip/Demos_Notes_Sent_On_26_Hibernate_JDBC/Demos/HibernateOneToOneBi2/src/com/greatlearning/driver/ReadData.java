package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Address;
import com.greatlearning.entity.Student;

public class ReadData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create session factory
				SessionFactory factory = new Configuration()
											.configure("hibernate.cfg.xml")
											.addAnnotatedClass(Student.class)
											.addAnnotatedClass(Address.class)
											.buildSessionFactory();

				// create session
				Session session = factory.getCurrentSession();

				try {

					// start transaction
					session.beginTransaction();
					
					// get the address object
					/*-------------------Read Address (Student)----22 Sep------------ */
					int tempAddressId=26;
					Address tempAddress=session.get(Address.class, tempAddressId);
					// select * from Address where id = tempAddressId;
					
					// Print the Address
					System.out.println("Address Details : "+tempAddress);
								
					//print the associated student values
					System.out.println("Associated Student : "+ tempAddress.getStudent()); /**/
					
					
					/*-------------------Read Student (Address)------22Sep---------- */
				/*	int studId=26;
					Student student = session.get(Student.class, studId);
					System.out.println("Student Details "+student);
					System.out.println("Associated Adddress "+student.getStudentAddress());
				*/	

					// commit transaction
					session.getTransaction().commit();

				} finally {
					factory.close();
				}

	}

}
