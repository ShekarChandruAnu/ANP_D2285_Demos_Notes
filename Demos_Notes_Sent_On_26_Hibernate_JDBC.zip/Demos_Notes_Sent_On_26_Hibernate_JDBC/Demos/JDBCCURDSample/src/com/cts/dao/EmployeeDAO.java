package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

import com.cts.model.Employee;

//REPOSITORY LAYER - DATA ACCESS OBJECT
public class EmployeeDAO {

	MyConnection mcon;// USER DEFINED
	Connection myCon;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
		
		public EmployeeDAO()
		{
			mcon = new MyConnection();
		}
		
		public ArrayList <Employee> getAllEmployees()
		{
			myCon = mcon.getMyConnection();
			ArrayList <Employee> employees = new ArrayList<Employee>();
			try 
			{
				stmt  = myCon.createStatement();
				rs = stmt.executeQuery("select * from Employees");
				//execute() executeUpdate()
				while(rs.next())
				{
					Employee e = new Employee();
					String empId = rs.getString(1);//constructor
					e.setEmployeeId(empId);
					
					e.setEmployeeName(rs.getString(2));
					e.setEmployeeAddress(rs.getString(3));
					e.setEmployeePhone(rs.getString(4));
					e.setEmployeeMail(rs.getString(5));
					e.setEmployeeSalary(rs.getFloat(6));
					e.setEmployeeDOJ(rs.getDate(7));
					
					employees.add(e);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return employees;
		}
		public Employee getEmployeeById(String empId)
		{
			myCon = mcon.getMyConnection();
			Employee e = new Employee();
			try {
				pstmt = myCon.prepareStatement("select * from Employees where employeeId = ?");
				pstmt.setString(1, empId);
				rs = pstmt.executeQuery();
				rs.next();
				e.setEmployeeId(rs.getString(1));
				e.setEmployeeName(rs.getString(2));
				e.setEmployeeAddress(rs.getString(3));
				e.setEmployeePhone(rs.getString(4));
				e.setEmployeeMail(rs.getString(5));
				e.setEmployeeSalary(rs.getFloat(6));
				e.setEmployeeDOJ(rs.getDate(7));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			return e;
		}
		public boolean insertEmployee(Employee e)
		{
			boolean flag = false;
			myCon = mcon.getMyConnection();
			try {
				pstmt = myCon.prepareStatement("insert into Employees values(?,?,?,?,?,?,?)");
				pstmt.setString(1, e.getEmployeeId());
				pstmt.setString(2, e.getEmployeeName());
				pstmt.setString(3, e.getEmployeeAddress());
				pstmt.setString(4, e.getEmployeePhone());
				pstmt.setString(5, e.getEmployeeMail());
				
				pstmt.setFloat(6, e.getEmployeeSalary());
				//Converting  util.Date to sql.Date object
				pstmt.setDate(7, utilToSqlDateConverter(e.getEmployeeDOJ()));
				pstmt.execute();
				flag = true;
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				flag = false;
				e1.printStackTrace();
			}
				
			
			return flag;
		}
		public boolean deleteEmployee(String empId)
		{
			boolean flag = false;
			myCon = mcon.getMyConnection();
			try {
				
				pstmt = myCon.prepareStatement("delete from Employees where employeeId = ?");
				pstmt.setString(1, empId);
				pstmt.execute();// executeQuery(ruled out)/executeUpdate
				flag = true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				flag = false;
				e.printStackTrace();
			}
			
			return flag;
		}
		public boolean updateEmployee(Employee e,String empId)
		{
			boolean flag = false;
			myCon = mcon.getMyConnection();
			try {//Name original
				pstmt = myCon.prepareStatement("update Employees set employeeName = ?,employeeAddress=?,employeePhone=?,employeeMail=?,employeeSalary=?,employeeDOJ=? where employeeId = ? ");
				pstmt.setString(1, e.getEmployeeName());
				pstmt.setString(2, e.getEmployeeAddress());
				pstmt.setString(3, e.getEmployeePhone());
				pstmt.setString(4, e.getEmployeeMail());
				pstmt.setFloat(5, e.getEmployeeSalary());
				pstmt.setDate(6, utilToSqlDateConverter(e.getEmployeeDOJ()));//Date to SqlDate
				pstmt.setString(7, empId);
				pstmt.execute();
				flag =  true;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				flag = false;
			}
			
			return flag;
		}
		public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
			java.sql.Date sqlDate = null;
			if (utDate != null) {
				sqlDate = new java.sql.Date(utDate.getTime());
			}
			// Date sqlDate = new Date(utDate.getTime())
			return sqlDate;
		}
		//String dtrDate = scan1.next() 2023-12-23
		public static java.util.Date stringToDateConverter(String stringDate) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat.setLenient(false);
			try {
				return dateFormat.parse(stringDate);
			} catch (ParseException pe) {
				return null;
			}
		}
		public String getMaxEmployeeIdEdao()
		{
			String maxId="";
			//select max(employeeId) from employees;
			myCon = mcon.getMyConnection();
			try {
				stmt = myCon.createStatement();
				rs = stmt.executeQuery("select max(employeeId) from employees");
				rs.next();
				maxId = rs.getString(1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return maxId;
		}
		
		public ArrayList <String> getAllIds()
		{
			ArrayList <String> ids = new ArrayList<String>();
			myCon = mcon.getMyConnection();
			try {
				stmt = myCon.createStatement();
				rs = stmt.executeQuery("select employeeId from Employees");
				
				while(rs.next())
				{
					String str = rs.getString(1);
					ids.add(str);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return ids;
		}
		public boolean checkIfIdExistsOrNot(String empId)
		{
			boolean flag = false;
			ArrayList <String> existingIds = new ArrayList<String>();
			
			existingIds = getAllIds();
			
			Iterator empIdIter = existingIds.iterator();
			while(empIdIter.hasNext())
			{
				String emplId = (String)empIdIter.next();
				if(emplId.equals(empId))
				{
					flag = true;
					break;
				}
			}
			
			
			return flag;
		}
	
}
