package com.cts.model;

import java.util.Date;
//POJO Plain Old Java Object - Model Class representing Data - table in DB
public class Employee {

	String employeeId;
	String employeeName;
	String employeeAddress;
	String employeePhone;
	String employeeMail;
	float employeeSalary;
	Date employeeDOJ;
	
	
	
	public Employee() {
		super();
	}



	public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone,
			String employeeMail, float employeeSalary, Date employeeDOJ) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.employeeMail = employeeMail;
		this.employeeSalary = employeeSalary;
		this.employeeDOJ = employeeDOJ;
	}



	public String getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	public String getEmployeeAddress() {
		return employeeAddress;
	}



	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}



	public String getEmployeePhone() {
		return employeePhone;
	}



	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}



	public String getEmployeeMail() {
		return employeeMail;
	}



	public void setEmployeeMail(String employeeMail) {
		this.employeeMail = employeeMail;
	}



	public float getEmployeeSalary() {
		return employeeSalary;
	}



	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}



	public Date getEmployeeDOJ() {
		return employeeDOJ;
	}



	public void setEmployeeDOJ(Date employeeDOJ) {
		this.employeeDOJ = employeeDOJ;
	}



	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeePhone=" + employeePhone + ", employeeMail=" + employeeMail
				+ ", employeeSalary=" + employeeSalary + ", employeeDOJ=" + employeeDOJ + "]";
	}

	

	
	
	
}
