package com.cts.service;

import java.util.ArrayList;

import com.cts.dao.EmployeeDAO;
import com.cts.model.Employee;

public class EmployeeService {
	
	EmployeeDAO edao;
	
		public EmployeeService()
		{
			edao = new EmployeeDAO();
				
		}
		
		public ArrayList <Employee> getAllEmployeeRecords()
		{
			ArrayList <Employee> employees = new ArrayList<Employee>();
			
			employees = edao.getAllEmployees();
			
			return employees;
		}
		
		public Employee getEmployeeRecordById(String empid)
		{
			Employee e = new Employee();
	
			e = edao.getEmployeeById(empid);
			
			return e;
		}
		public boolean insertEmployeeRecord(Employee e)
		{
			boolean flag = false;
	
			flag = edao.insertEmployee(e);
			
			return flag;
		}
		public boolean deleteEmployeeRecord(String empId)
		{
			boolean flag = false;
			flag = edao.deleteEmployee(empId);
			return flag;
		}
		public boolean updateEmployeeRecord(Employee  empUpd,String empId)
		{
			boolean flag = false;
			
			flag = edao.updateEmployee(empUpd, empId);
			
			return flag;
		}
		public String getMaxEmployeeId()
		{
			String maxEmplId = "";
			maxEmplId = edao.getMaxEmployeeIdEdao();
			
			return maxEmplId;
		}
	
		public ArrayList <String> getAllEmployeeIds()
		{
			ArrayList <String> empIds = new ArrayList<String>();
			
			empIds = edao.getAllIds();
			
			return empIds;
		}
		public boolean checkIfEmployeeIdExists(String id)
		{
			boolean flag = false;
			
			flag = edao.checkIfIdExistsOrNot(id);
			
			return flag;
		}
	

}
