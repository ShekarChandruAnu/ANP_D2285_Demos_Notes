package com.cts.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

public class EmployeeDataMenu {

	Scanner scan1;
	String reply;
	String choice;
	EmployeeService empSvc;
	
	
	public EmployeeDataMenu() {
		super();
		
		scan1 = new Scanner(System.in);
		reply = "Yes";
		choice ="";
		empSvc = new EmployeeService();
	}



	public void showMenu()
	{
		while(reply.equals("Yes") || reply.equals("YES") || reply.equals("yes"))
		{
			System.out.println("-----------Welcome to Employees Data Manipulation Page....----------");
			System.out.println("----------MAIN MENU-----------------");
			System.out.println("1. View All Employees ");
			System.out.println("2. View Employee By ID ");
			System.out.println("3. Insert Employee Record ");
			System.out.println("4. Delete Employee By ID ");
			System.out.println("5. Update Employee  ");
			System.out.println("6. Exit Menu...");
			
			System.out.println("Enter your Choice .... 1 2 3 4 5 6");
			choice = scan1.next();
				switch(choice)
				{
					case "1":
					{
						System.out.println("Getting All Employees...");
						ArrayList <Employee> employees = empSvc.getAllEmployeeRecords();
						System.out.println("The Employee Details are....");
						Iterator <Employee> empIter = employees.iterator();
						while(empIter.hasNext())
						{
							Employee e = empIter.next();
							System.out.println(e);
						}
						
					break;
					}
					case "2":
					{
						System.out.println("Getting Employee By ID...");
						displayExistingIds();
						String employeeId;
						System.out.println("Enter the Id of the Employee whose Record you wish to See...");
						employeeId = scan1.next();
						if(checkIfIdExists(employeeId))
						{
							Employee emp = empSvc.getEmployeeRecordById(employeeId);
							System.out.println("The Employee Record Retrieved is ");
							System.out.println(emp);
						}
						else
						{
							System.out.println("Sorry, Entered Id does not exist...");
						}
						break;
					}
					case "3":
					{
						boolean flag = false;
						System.out.println("Inserting Employee Record...");
						Employee e1 = new Employee();
						String empId;
						
						
						empId = generateId();
						System.out.println("Employee Id Generated is "+empId);
						System.out.println("Enter the Other Details...");
						e1 = getEmployeeData();
						e1.setEmployeeId(empId);
						
					
					/*	Removed Redundant Code - REFACTORING CODE- REDESIGNing of the code
					 empName,empAddr,empPhon,empMail;
						float empSalary;
						String empDOJstr;
						Date empDOJdt;
						
						System.out.println("Enter the Employee Id...");
						empId = scan1.next();
						//To Auto Generate EmployeeId
					  System.out.println("Enter the Employee Name ...");
						empName = scan1.next();
						System.out.println("Enter the Employee Address ...");
						empAddr = scan1.next();
						System.out.println("Enter the Employee Phone...");
						empPhon = scan1.next();
						System.out.println("Enter the Employee eMail Id...");
						empMail = scan1.next();
						System.out.println("Enter the Employee Salary ....");
						empSalary = scan1.nextFloat();
						System.out.println("Enter the DOJ in yyyy-mm-dd format...");
						empDOJstr = scan1.next();
						//Converting String to util.Date object
						empDOJdt = stringToDateConverter(empDOJstr);
						
						e1.setEmployeeName(empName);
						e1.setEmployeeAddress(empAddr);
						e1.setEmployeePhone(empPhon);
						e1.setEmployeeMail(empMail);
						e1.setEmployeeSalary(empSalary);
						e1.setEmployeeDOJ(empDOJdt

					 	*/
						
						flag = empSvc.insertEmployeeRecord(e1);
						if(flag)
						{
							System.out.println("Inserted Record Successfully....");
						}
						else
						{
							System.out.println("Insertion Failed, Please check...");
						}
						
						
						break;
					}
					case "4":
					{
						boolean flag = false;
						System.out.println("Deleting Employee By ID...");
						String emplId;
					
						displayExistingIds();
						
						System.out.println("Enter the ID of the Employee,whose record you wish to Delete");
						emplId = scan1.next();
						if(checkIfIdExists(emplId))
						{
							flag = empSvc.deleteEmployeeRecord(emplId);
							if(flag)
							{
								System.out.println("Record Deleted Successfully for the Employee with Id "+emplId);
							}
							else
							{
								System.out.println("Deletion Failed!!!");
							}
						}
						else
						{
							System.out.println("Sorry, Entered Id does not exist...");
						}
						break;
					}
					case "5":
					{
						System.out.println("Updating Employee...");
						
						boolean flag = false;
						
						Employee e1 = new Employee();
						String empId;
						
						displayExistingIds();
						
						System.out.println("Enter the ID of the EMployee whose record you wish to Modify..");
						empId = scan1.next();
						
						if(checkIfIdExists(empId))
						{
						
							System.out.println("Current Record of "+empId+"  is :");
							Employee emp = empSvc.getEmployeeRecordById(empId);
						
							System.out.println(emp);
							
							System.out.println("Enter the New Details for the Employee...");
						
							
							emp = getEmployeeData();
							emp.setEmployeeId(empId);
							flag  = empSvc.updateEmployeeRecord(emp,empId);
							if(flag)
							{
								System.out.println("Updated Record Successfully for the Employee with Id "+empId);
							}
							else
							{
								System.out.println("Sorry , Updation Failed!!!");
							}
						}
						else
						{
							System.out.println("Sorry, Entered Id does not exist...");
						}
						//REFACTORING
					/*	REMOVED  REDUNDANT CODE
					 * empName,empAddr,empPhon,empMail;
						float empSalary;
						String empDOJstr;
						Date empDOJdt;
					 * 
					 * System.out.println("Enter the Employee Name ...");
						empName = scan1.next();
						System.out.println("Enter the Employee Address ...");
						empAddr = scan1.next();
						System.out.println("Enter the Employee Phone...");
						empPhon = scan1.next();
						System.out.println("Enter the Employee eMail Id...");
						empMail = scan1.next();
						System.out.println("Enter the Employee Salary ....");
						empSalary = scan1.nextFloat();
						System.out.println("Enter the DOJ in yyyy-mm-dd format...");
						empDOJstr = scan1.next();
						//Converting String to util.Date object
						empDOJdt = stringToDateConverter(empDOJstr);
					//	e1.setEmployeeId(empId);
						emp.setEmployeeName(empName);
						emp.setEmployeeAddress(empAddr);
						emp.setEmployeePhone(empPhon);
						emp.setEmployeeMail(empMail);
						emp.setEmployeeSalary(empSalary);
						emp.setEmployeeDOJ(empDOJdt);*/
						
						
						break;
					}
					case "6":
					{
						System.out.println("Exiting App...");
						//System.exit(0);
						break;
					}
					default:
					{
						System.out.println("Sorry Valid entry is 1 - 6...");
						break;
					}
				}
			
			System.out.println("Do You Wish to Continue yes/no");
			reply = scan1.next();
		}
		System.out.println("We Are Out of Loop...");
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		if (utDate != null) {
			sqlDate = new java.sql.Date(utDate.getTime());
		}
		return sqlDate;
	}
	
	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}
	public Employee getEmployeeData()
	{
		Employee e1 = new Employee();// without value for empId
		String empId,empName,empAddr,empPhon,empMail;
		float empSalary;
		String empDOJstr;
		Date empDOJdt;
		//AUTO GENERATED 
		System.out.println("Enter the Employee Name ...");
		empName = scan1.next();
		System.out.println("Enter the Employee Address ...");
		empAddr = scan1.next();
		System.out.println("Enter the Employee Phone...");
		empPhon = scan1.next();
		System.out.println("Enter the Employee eMail Id...");
		empMail = scan1.next();
		System.out.println("Enter the Employee Salary ....");
		empSalary = scan1.nextFloat();
		System.out.println("Enter the DOJ in yyyy-mm-dd format...");
		empDOJstr = scan1.next();
		//Converting String to util.Date object
		empDOJdt = stringToDateConverter(empDOJstr);
	//	e1.setEmployeeId(empId);
		e1.setEmployeeName(empName);
		e1.setEmployeeAddress(empAddr);
		e1.setEmployeePhone(empPhon);
		e1.setEmployeeMail(empMail);
		e1.setEmployeeSalary(empSalary);
		e1.setEmployeeDOJ(empDOJdt);
		
		return e1;
	}
	public String generateId()
	{
		String genEmpId="";
		String maxEmpId = "";
		maxEmpId = empSvc.getMaxEmployeeId();//E013
		String preFixId,postFixId;
		preFixId = maxEmpId.substring(0,1); //E
		postFixId = maxEmpId.substring(1, maxEmpId.length());//"009"
		int pIdInt = Integer.parseInt(postFixId);//9
		pIdInt+=1; //10
		if((pIdInt >= 0) &&(pIdInt <= 9))
		{
			genEmpId = "E00"+pIdInt;
		}
		else if((pIdInt >= 10) &&(pIdInt <= 99))
		{
			genEmpId = "E0"+pIdInt;//E010
		}
		else if((pIdInt >= 100) &&(pIdInt <= 999))
		{
			genEmpId = "E"+pIdInt;
		}
		else
		{
			genEmpId="NotGenerated";
		}
		
		return genEmpId;//E014
	}
	public void displayExistingIds()
	{
		ArrayList <String> empIds = new ArrayList<String>();
		empIds = empSvc.getAllEmployeeIds();
		System.out.println("Existing EmployeeIds are ...");
		Iterator idIter = empIds.iterator();
		while(idIter.hasNext())
		{
			String str = (String)idIter.next();
			System.out.println(str);
		}
	}
	public boolean checkIfIdExists(String id)
	{
		boolean flag = false;
		flag = empSvc.checkIfEmployeeIdExists(id);
		
		return flag;
	}
}
