package com.cts.util;

public class MenuLoader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDataMenu edm = new EmployeeDataMenu();
		edm.showMenu();
	}

}
