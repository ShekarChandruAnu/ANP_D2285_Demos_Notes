package com.maha.anu;

import java.util.Scanner;

public class IntermediateClass {
	 
	
	public void helperMethod(Parser parser,String fileType)
	{
		parser.parse(fileType);
		parser.displayNonAbstract();
	}
	
	public static void main(String[] args)
	{
		Scanner scan1 = new Scanner(System.in);
		System.out.println("Enter the Type of file you wish to Parse....");
		IntermediateClass iClass = new IntermediateClass();
		String typeOfFile="";
		Parser parser;
		//parser = new Parser(); Cannot instantiate Abstract Class - Parser
		typeOfFile = scan1.next();
		switch(typeOfFile)
		{
			case "xml":
			{
				parser = new XmlParser();
				iClass.helperMethod(parser, typeOfFile);
				break;
			}
			case "json":
			{
				parser = new JsonParser();
				iClass.helperMethod(parser, typeOfFile);
				break;
			}
			case "pdf":
			{
				parser = new PDFParser();
				iClass.helperMethod(parser, typeOfFile);
				break;
			}
			default:
			{
				System.out.println("Not a Valid File Type");
				break;
			}
		}
	}

}
