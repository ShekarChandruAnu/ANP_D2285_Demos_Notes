package com.maha.anu1;

public class Base {
	
	public void display()
	{
		System.out.println("Displaying Base Class....");
	}

}
