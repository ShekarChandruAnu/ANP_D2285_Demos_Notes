package com.maha.anu1;

public class Derived  extends Base{
	
	@Override
	public void display()
	{
		System.out.println("Displaying Derived Class....");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Base base1 = new Base();
		base1.display();
		
		Base base = new Derived();
		base.display();
		
		Derived der1 = 	(Derived) new Base();
		//EXCEPTION - CLASS CAST EXCEPTIOn
		
		int x = 100;
		long y = 1020202;
		x = (int)y;
		
		
	}

}
