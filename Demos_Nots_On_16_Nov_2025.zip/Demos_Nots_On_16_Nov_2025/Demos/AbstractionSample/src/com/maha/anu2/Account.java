package com.maha.anu2;

public interface Account extends CreditCardAccount,DebitCardAccount{

	public void openAccount();
	public void closeAccount();
}
