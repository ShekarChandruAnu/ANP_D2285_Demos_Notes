package com.maha.anu2;

public interface DebitCardAccount {

	public void calculateInterest();
	public void withdraw();
	public void deposit();
}
