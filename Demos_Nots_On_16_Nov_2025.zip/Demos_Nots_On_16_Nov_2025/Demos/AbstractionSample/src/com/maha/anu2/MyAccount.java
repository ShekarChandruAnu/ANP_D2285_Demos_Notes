package com.maha.anu2;

public class MyAccount extends InterestCalculator implements Account,Insurance{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mac = new MyAccount();
		mac.openAccount();
		//DEBIT CARD FEATURES
		mac.deposit();
		mac.withdraw();
		//CREDITCARD FEATURES
		mac.calculateOutstandingAmt();
		mac.calculateRedemptionPoints();
		mac.calculateInterest();
		//Insurance features
		mac.openPolicy();
		mac.calculatePremium();
		mac.terminatePolicy();
		mac.showInterestPolicy();
		
		mac.closeAccount();

	}

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Outstanding AMount successfully....");
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Redemption Points successfully....");
	}

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Interest AMount successfully....");
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Withdrew AMount successfully....");
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Deposited  AMount successfully....");
	}

	@Override
	public void openPolicy() {
		// TODO Auto-generated method stub
		System.out.println("Opened Policy successfully....");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("Terminated Policy successfully....");
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Premium  AMount successfully....");
	}

	@Override
	public void openAccount() {
		// TODO Auto-generated method stub
		System.out.println("Opened Account successfully....");
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Cloased Account successfully....");
		
	}

}
