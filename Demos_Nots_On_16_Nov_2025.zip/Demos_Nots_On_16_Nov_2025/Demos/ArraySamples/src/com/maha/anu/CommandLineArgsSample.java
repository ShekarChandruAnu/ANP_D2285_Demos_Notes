package com.maha.anu;

public class CommandLineArgsSample {

	public static void main(String[] cities) {
		// TODO Auto-generated method stub
		System.out.println("The Cities are ....");
		for(int i=0;i<cities.length;i++)
		{
			System.out.println(cities[i]);
		}
		// 6 MINU
		System.out.println("-----Cities are....----");
		for(String city:cities)
		{
			System.out.println(city);
		}

	}

}
