package com.maha.anu;

public class JaggedArraySample {

	public void manipulateJaggedArray()
	{
		int jagArr[][] = new int [3][];
		
		jagArr[0] = new int[4];
		jagArr[1] = new int[5];
		jagArr[2] = new int[3];
		
		for(int i=0;i<4;i++)
		{
			jagArr[0][i] = (i+1)*100;
			System.out.print(jagArr[0][i]+" ");
		}
		System.out.println();
		for(int i=0;i<5;i++)
		{
			jagArr[1][i] =(i+1)*1000;
			System.out.print(jagArr[1][i]+" ");
		}
		System.out.println();
		for(int i=0;i<3;i++)
		{
			jagArr[2][i] =(i+1)*10000;
			System.out.print(jagArr[2][i]+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JaggedArraySample jars = new JaggedArraySample();
		jars.manipulateJaggedArray();

	}

}
