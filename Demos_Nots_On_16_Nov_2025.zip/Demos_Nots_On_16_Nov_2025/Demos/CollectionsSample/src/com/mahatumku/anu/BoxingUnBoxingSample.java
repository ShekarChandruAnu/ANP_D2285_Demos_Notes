package com.mahatumku.anu;

public class BoxingUnBoxingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int score  = 87;
		// BOXING IMPLICIT
		Object scoObject = score;
		System.out.println("The Value typed data boxed into Reference Type "+scoObject);
		//UNBOXING - EXPLICIT
		int myScore = (int) scoObject;
		System.out.println("Unboxed data in Value Type "+myScore);

	}

}
