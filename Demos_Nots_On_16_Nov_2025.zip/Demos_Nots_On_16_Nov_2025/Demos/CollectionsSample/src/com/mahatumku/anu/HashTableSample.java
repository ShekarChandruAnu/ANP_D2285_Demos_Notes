package com.mahatumku.anu;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashTableSample {
	/*HashMap
	TreeMap */
	//SYNCHRONIZED  /Keys not sorted / Keys unique
	Hashtable <String,Employee> employeeTable = new Hashtable<String,Employee>();
	public void populateHashTable()
	{
		 Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		
		 Employee e2 =new Employee("E002","Mahesh","JayaNagar","7652993939",14000);
		 Employee e3 =new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000);
		 Employee e4 =new Employee("E004","Maheshwari","Malleswaram","7656893939",18000);
		 Employee e5 =new Employee("E005","Rajesh","JayaNagar","7652996789",22000);
		 Employee e6 =new Employee("E006","Rakesh","Malleswaram","7321993939",21000);
		 
		 employeeTable.put("E001", e1);
		 employeeTable.put("E002", e2);
		 employeeTable.put("E003", e3);
		 employeeTable.put("E004", e4);
		 employeeTable.put("E005", e5);
		 //employeeTable.put("E006", new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
		 employeeTable.put("E006", e6);
		 
	}
	public void fetchHashTableData()
	{
		 Enumeration <String> keyEnumer = employeeTable.keys();
		 	while(keyEnumer.hasMoreElements())
		 	{
		 		String myKey = keyEnumer.nextElement();
		 		System.out.println("The Value for the Key "+myKey+"  Is : "+employeeTable.get(myKey));
		 	}
	}
	public void fetchHashTableDataThruKeySet()
	{
		Set <String> myKeySet = employeeTable.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for the Key "+myKey+" is :"+employeeTable.get(myKey));
		}
	}
	public void fecthHastTableUsingValues()
	{
				Collection <Employee> employees = employeeTable.values();
				Iterator <Employee> empIter = employees.iterator();
				while(empIter.hasNext())
				{
					Employee e = empIter.next();
					System.out.println(e);
				}
				
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample hts = new HashTableSample();
		System.out.println("-------Enumerated thru keys-------");
		hts.populateHashTable();
		hts.fetchHashTableData();
		System.out.println("--------Iterated Thru Keys------");
		hts.fetchHashTableDataThruKeySet();
		System.out.println("---------Iterated Thru Values---------------");
		hts.fecthHastTableUsingValues();

	}

}
