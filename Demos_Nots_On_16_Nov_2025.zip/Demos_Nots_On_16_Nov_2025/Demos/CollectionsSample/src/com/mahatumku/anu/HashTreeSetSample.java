package com.mahatumku.anu;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashTreeSetSample {

	HashSet <String> cityHSet = new HashSet<String>();
	TreeSet <String> cityTSet = new TreeSet<String>();
	TreeSet <Employee> empTSet = new TreeSet<Employee>();
	public void manipulateHashSet()
	{
		cityHSet.add("Faridabad");
		cityHSet.add("Delhi");
		cityHSet.add("Chandigarh");
		cityHSet.add("Ahmedabad");
		cityHSet.add("Bangalore");
		cityHSet.add("Chennai");
		cityHSet.add("Gandhinagar");
		cityHSet.add("Ernakulam");
		
	}
	public void displayHashSet()
	{
		Iterator <String> hSetIter = cityHSet.iterator();
		while(hSetIter.hasNext())
		{
			System.out.println(hSetIter.next());
		}
	}
	public void manipulateTreeSet()
	{
		cityTSet.add("Faridabad");
		cityTSet.add("Delhi");
		cityTSet.add("Chandigarh");
		cityTSet.add("Ahmedabad");
		cityTSet.add("Bangalore");
		cityTSet.add("Chennai");
		cityTSet.add("Gandhinagar");
		cityTSet.add("Ernakulam");
	}
	public void displayTreeSet()
	{
		Iterator <String> tSetIter = cityTSet.iterator();
		while(tSetIter.hasNext())
		{
			System.out.println(tSetIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashTreeSetSample htss = new HashTreeSetSample();
		System.out.println("------HASHSET-----");
		htss.manipulateHashSet();
		htss.displayHashSet();
		System.out.println("------TREESET-----");
		htss.manipulateTreeSet();
		htss.displayTreeSet();

	}

}
