package com.mahatumku.anu;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	LinkedList empLinkList = new LinkedList();
	
	public void manipulateLinkedList()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		empLinkList.add(e1);
		empLinkList.add(new Employee("E002","Mahesh","JayaNagar","7652993939",14000));
		empLinkList.add(new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000));
		empLinkList.add(new Employee("E004","Maheshwari","Malleswaram","7656893939",18000));
		empLinkList.add(new Employee("E005","Rajesh","JayaNagar","7652996789",22000));
		empLinkList.add(new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
		empLinkList.addFirst(new Employee("E00A","Kishore Kumar","Koramangala","7384993939",13000));
		empLinkList.addLast(new Employee("E007","Kadambari","Malleswaram","7464993939",14000));
		empLinkList.add(3,new Employee("E003a","Keerthan","JayaNagar","7645996549",16000));
	}
	public void displayLinkedList()
	{
		System.out.println(empLinkList);
		System.out.println("------For Each Loop-------");
		for(Object o:empLinkList)
		{
			System.out.println((Employee)o);
		}
		System.out.println("----------Using Iterator----------");
		Iterator empIter = empLinkList.iterator();
		while(empIter.hasNext())
		{
			Employee employee = (Employee)empIter.next();
			System.out.println(employee);
		}
		System.out.println("Record in the index 3 "+empLinkList.get(3));
		
		
	}
	public void displayDescendingList()
	{
		
		Iterator empDescIter = empLinkList.descendingIterator();
		while(empDescIter.hasNext())
		{
			Employee employee = (Employee) empDescIter.next();
			System.out.println(employee);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample lls = new LinkedListSample();
		lls.manipulateLinkedList();
		lls.displayLinkedList();
		System.out.println("------Descending ----");
		lls.displayDescendingList();

	}

}
