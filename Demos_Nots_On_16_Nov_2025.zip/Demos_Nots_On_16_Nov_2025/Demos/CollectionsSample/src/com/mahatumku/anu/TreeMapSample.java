package com.mahatumku.anu;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapSample {

	TreeMap <String,Employee> empTreeMap = new TreeMap<String,Employee>(); 
	
	public void populateTreeMap()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		Employee e2 =new Employee("E002","Mahesh","JayaNagar","7652993939",14000);
		Employee e3 =new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000);
		Employee e4 =new Employee("E004","Maheshwari","Malleswaram","7656893939",18000);
		Employee e5 =new Employee("E005","Rajesh","JayaNagar","7652996789",22000);
		Employee e6 =new Employee("E006","Rakesh","Malleswaram","7321993939",21000);
		
		empTreeMap.put("E002",e2);
		empTreeMap.put("E005",e5);
		empTreeMap.put("E004",e4);
		empTreeMap.put("E001",e1);
		empTreeMap.put("E006",e6);
		empTreeMap.put("E003",e3);



		
	
	}
	public void fetchTreeMapUsingEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = empTreeMap.entrySet();
		Iterator <Entry <String,Employee>> myEntryIter  = myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntryIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" And Corresponding Value is "+myEntry.getValue());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMapSample tms = new TreeMapSample();
		tms.populateTreeMap();
		tms.fetchTreeMapUsingEntrySet();

	}

}
