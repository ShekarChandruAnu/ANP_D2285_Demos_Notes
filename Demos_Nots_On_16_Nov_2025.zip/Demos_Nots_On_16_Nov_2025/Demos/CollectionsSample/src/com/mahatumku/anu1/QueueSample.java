package com.mahatumku.anu1;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {
	//FIFO
	Queue <String> myQueue = new PriorityQueue<String>();
	public void populateQueue()
	{
		
		myQueue.add("Bangalore");
		myQueue.add("Mangalore");
		myQueue.add("Hyderabad");
		myQueue.add("Chennai");
		myQueue.add("NewDelhi");
		myQueue.add("Mumbai");
		myQueue.add("Kolkata");
	}
// COMPARATOR  COMPARABLE
	public void fetchQueueThruRemove()
	{
		System.out.println("The Size of the Queue before Removing all "+myQueue.size());
		while(myQueue.isEmpty() == false)
		{
			String cityInQueue = myQueue.remove();
			System.out.println("City in Queue "+cityInQueue);
		}
		System.out.println("The Size of the Queue after Removing all "+myQueue.size());
	}
	public void fetchQueuThruIterator()
	{
			Iterator <String> qIter = myQueue.iterator();
			while(qIter.hasNext())
			{
				System.out.println("City Iterated "+qIter.next());
			}
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueSample qSample = new QueueSample();
		qSample.populateQueue();
		System.out.println("---------Fetch Thru Iterr--------");
		qSample.fetchQueuThruIterator();
		System.out.println("---------Fetch Thru remove--------");
		qSample.fetchQueueThruRemove();
		
		

	}

}
