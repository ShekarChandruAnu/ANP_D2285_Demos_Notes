package com.mahatumku.anu1;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {

	Stack <String> myStack = new Stack<String>();
	public void populateStackUsingPush()
	{
		myStack.push("Bangalore");
		myStack.push("Mangalore");
		myStack.push("Hyderabad");
		myStack.push("Chennai");
		myStack.push("NewDelhi");
		myStack.push("Mumbai");
		myStack.push("Kolkata");
	}
	
	public void fetchStackThruPop()
	{
		System.out.println("The Size before popping all elements "+myStack.size());
		System.out.println("The Peeked Element is "+myStack.peek());
		System.out.println("The Size after peeking top most element "+myStack.size());
		while(myStack.isEmpty() == false)
		{
			String stackElement = myStack.pop();
			System.out.println("The City is "+stackElement);
		}
		System.out.println("The Size after popping all elements "+myStack.size());
	}
	
	public void populateStackUsingAdd()
	{
		myStack.add("Bangalore");
		myStack.add("Mangalore");
		myStack.add("Hyderabad");
		myStack.add("Chennai");
		myStack.add("NewDelhi");
		myStack.add("Mumbai");
		myStack.add("Kolkata");
	}
	
	public void fetchStackThruIterator()
	{
		System.out.println("The Size before iterating all elements "+myStack.size());
		Iterator <String> stackIter = myStack.iterator();
		while(stackIter.hasNext())
		{
			String city = stackIter.next();
			System.out.println("City Iterated thru from a Stack "+city);
		}
		System.out.println("The Size after iterating all elements "+myStack.size());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StackSample sample = new StackSample();
		sample.populateStackUsingPush();
		sample.fetchStackThruPop();
		System.out.println("----------");
		sample.populateStackUsingAdd();
		sample.fetchStackThruIterator();

	}

}
