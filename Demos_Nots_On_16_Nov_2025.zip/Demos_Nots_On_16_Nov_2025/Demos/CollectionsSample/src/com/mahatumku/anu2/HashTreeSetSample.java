package com.mahatumku.anu2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

import com.mahatumku.anu.Employee;

public class HashTreeSetSample {

	/*
	 * TreeSet String - 
	 * TreeSet Employee ? 
	 */
	HashSet <String> cityHSet = new HashSet<String>();
	TreeSet <String> cityTSet = new TreeSet<String>();
	TreeSet <Employee> empTSet = new TreeSet<Employee>();
	public void manipulateHashSet()
	{
		cityHSet.add("Faridabad");
		cityHSet.add("Delhi");
		cityHSet.add("Chandigarh");
		cityHSet.add("Ahmedabad");
		cityHSet.add("Bangalore");
		cityHSet.add("Chennai");
		cityHSet.add("Gandhinagar");
		cityHSet.add("Ernakulam");
		
	}
	
	public void displayHashSet()
	{
		Iterator <String> hSetIter = cityHSet.iterator();
		while(hSetIter.hasNext())
		{
			System.out.println(hSetIter.next());
		}
	}
	public void manipulateTreeSet()
	{
		cityTSet.add("Faridabad");
		cityTSet.add("Delhi");
		cityTSet.add("Chandigarh");
		cityTSet.add("Ahmedabad");
		cityTSet.add("Bangalore");
		cityTSet.add("Chennai");
		cityTSet.add("Gandhinagar");
		cityTSet.add("Ernakulam");
	}
	public void displayTreeSet()
	{
		Iterator <String> tSetIter = cityTSet.iterator();
		while(tSetIter.hasNext())
		{
			System.out.println(tSetIter.next());
		}
	}
	public void addEmployeeToTreeSet()
	{
		Employee e1 = new Employee("E001","Kiran Kumar","RTNagar","9832993939",10000);
		empTSet.add(e1);
		empTSet.add(new Employee("E002","Mahesh","JayaNagar","7652993939",14000));
		empTSet.add(new Employee("E003","Keerthana","ViJayaNagar","7652996549",16000));
		empTSet.add(new Employee("E004","Maheshwari","Malleswaram","7656893939",18000));
		empTSet.add(new Employee("E005","Rajesh","JayaNagar","7652996789",22000));
		empTSet.add(new Employee("E006","Rakesh","Malleswaram","7321993939",21000));
	}
	public void displayEmployeeTreeSet()
	{
		Iterator <Employee> tEmpSetIter = empTSet.iterator();
		while(tEmpSetIter.hasNext())
		{
			System.out.println(tEmpSetIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashTreeSetSample htss = new HashTreeSetSample();
	/*	System.out.println("------HASHSET-----");
		htss.manipulateHashSet();
		htss.displayHashSet();
		System.out.println("------TREESET-----");
		htss.manipulateTreeSet();
		htss.displayTreeSet();*/
		htss.addEmployeeToTreeSet();
		htss.displayEmployeeTreeSet();

	}

}
