package com.mahatumku.anu3;

import java.util.Comparator;

public class StudScoreSorter implements Comparator <Student>{

	Integer score;
	
	@Override
	public int compare(Student student1, Student student2) {
		// TODO Auto-generated method stub
		//score.compare(x, y)
		//Integer.compare(x,y)
		if( student1.getScore() > student2.getScore())
		{
			return 1;
		}
		else if(student1.getScore() < student2.getScore())
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	

}
