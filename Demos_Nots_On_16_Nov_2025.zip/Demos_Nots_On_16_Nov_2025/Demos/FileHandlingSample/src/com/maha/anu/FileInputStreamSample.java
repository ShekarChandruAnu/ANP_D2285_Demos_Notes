package com.maha.anu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {

	FileInputStream fis;
	byte[] mybytes = new byte[100];
	public void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("customer.txt");
			fis.read(mybytes); 
			String str = new String(mybytes);
			System.out.println("The Data read from the file Through Binary Stream "+str);
			fis.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException ioe) {
			// TODO Auto-generated catch block
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStreamSample fiss = new FileInputStreamSample();
		fiss.readFromBinaryStream();

	}

}
