package com.maha.anu1;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamSample {

	BufferedOutputStream bos;
	byte[] mybytes = new byte[100];
	String mystr = "we are writing to supplier file through Binary Stream chained thru Buffer";
	public void writeToBinaryStreamThruBuffer()
	{
		//bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"),100000);
		try {
			bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"));
			mybytes = mystr.getBytes();
			bos.write(mybytes);
			bos.flush();
			bos.close();
			System.out.println("Wrote to binary stream successfully thru buffer..");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	//Intellisense - IDE INTELLIJ /VSCODE Editor
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedOutputStreamSample boss = new BufferedOutputStreamSample();
		boss.writeToBinaryStreamThruBuffer();
	}

}
