package com.maha.anu1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderSample {
	BufferedReader br;
	String str;
	public void readFromCharStreamThruBuffer() {
		try {
			br=new BufferedReader(new FileReader("dealer.txt"));
			str=br.readLine();
			System.out.println("Data read from character stream through a buffer "+str);
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException ioe) {
			// TODO Auto-generated catch block
			ioe.printStackTrace();
		}

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReaderSample brs=new BufferedReaderSample();
		brs.readFromCharStreamThruBuffer();
	}

}
