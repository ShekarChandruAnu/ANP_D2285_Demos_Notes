package com.maha.anu2;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferedOutputStreamToMonitor {

	BufferedOutputStream bos;
	String str ="This Data Should Go To Monitor";
	byte[] mybytes = new byte[100];
	public void writeToMonitorThruBuffer()
	{
		mybytes = str.getBytes();
		//bos = new BufferedOutputStream(new FileOutputStream("customer.txt"));
		bos = new BufferedOutputStream(System.out);
		try {
			bos.write(mybytes);//this data is written onto ????MONITOR
			System.out.println("We wrote to Monitor thru Buffer Successfully...");
			
			bos.flush();
			bos.close();
				} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedOutputStreamToMonitor bostm = new BufferedOutputStreamToMonitor();
		bostm.writeToMonitorThruBuffer();

	}

}
