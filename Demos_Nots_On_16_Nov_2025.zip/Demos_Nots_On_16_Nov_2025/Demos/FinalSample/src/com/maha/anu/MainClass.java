package com.maha.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyFinalClass mfc = new MyFinalClass();
		mfc.myFinalMethod();
		
		NonFinalClass nfc = new NonFinalClass();
		nfc.nonFinalMethod();
		nfc.finalMethod();

	}

}
