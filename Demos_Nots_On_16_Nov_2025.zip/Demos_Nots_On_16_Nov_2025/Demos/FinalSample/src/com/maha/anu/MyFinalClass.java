package com.maha.anu;

public final class MyFinalClass {
	
	// BY default all methods in final class are final which cannot be overridden
	public void myFinalMethod()
	{
		System.out.println("This is final Method cannot be overridden");
	}

}
/* FINAL CLASS CANNOT BE INHERITED
class MyDerivedFinalClass extends MyFinalClass
{
	
}*/
