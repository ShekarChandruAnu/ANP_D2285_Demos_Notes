package com.maha.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Furniture furniture1 = new Furniture();
		furniture1.acceptFurnitureDetails();
		furniture1.displayFurnitureDetails();
		System.out.println("---Dealing with Book SHelf---");
		BookShelf shelf1 = new BookShelf();
		shelf1.acceptBookShelfDetails();
		shelf1.displayBookShelfDetails();

	}

}
