package com.maha.anu;

public class Table extends Furniture {

	protected int noOfLegs;
	public void calculateCost()
	{
		
	}
	
}
