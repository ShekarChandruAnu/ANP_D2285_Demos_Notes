package com.maha.anu;

public class Employee {

	// Data Members defined Private to represent Characteristics of Employee
	private String employeeId;
	private String employeeName;
	private String employeeAddress;
	private String employeePhone;
	private int employeeSalary;
	private float incomeTax;
//	private boolean isEligibleForESOP;
	
	//Method to initialize the Data 
/*	public void initializeData()
	{
		employeeId = "E001";
		employeeName = "Harsha";
		employeeAddress = "RTNagar";
		employeePhone = "9484994994";
		employeeSalary=10000;
		incomeTax = 12.34f;
	}*/
	
	public Employee()
	{
		employeeId = "E001";
		employeeName = "Harsha";
		employeeAddress = "RTNagar";
		employeePhone = "9484994994";
		employeeSalary=10000;
		incomeTax = 12.34f;
	}/**/
	// SYstem.out.println()
	/*
	 * public  Employee(String employeeId1,String employeeName1,String employeeAddress1,String employeePhone1,int employeeSalary1,float incomeTax1)
	{
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.employeeSalary = employeeSalary;
		this.incomeTax = incomeTax;
	}/**/
	 
	
	
	//OVERLOADED CONSTRUCTOR
	public  Employee(String employeeId,String employeeName,String employeeAddress,String employeePhone,int employeeSalary,float incomeTax)
	{
		//MIRRORING
		// this represents the instance of the current class
		//Employee e = new Employee();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.employeeSalary = employeeSalary;
		this.incomeTax = incomeTax;
	}/**/
	// PARAMETERS TERM IS USED TO REPRESENT THE VARIABLES PASSED AS VALUES IN THE METHOD
	// ARGUMENTS ARE USED TO REFER TO THE VALUES
	public  Employee(String employeeId,String employeeName,String employeeAddress,String employeePhone)
	{
		//MIRRORING
		// this represents the instance of the current class
		//Employee e = new Employee();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		
	}
	
	public  Employee(String employeeId,String employeeName,String employeeAddress)
	{
		//MIRRORING
		// this represents the instance of the current class
		//Employee e = new Employee();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		
		
	}
	public void displayEmployeeDetails()
	{
		System.out.println("The Employee Details are...");
		System.out.println("Employee Id "+employeeId);
		System.out.println("Employee Name :"+employeeName);
		System.out.println("Employee Address "+employeeAddress);
		System.out.println("Employee Phone "+employeePhone);
		System.out.println("Employee Salary "+employeeSalary);
		System.out.println("Income Tax Percentage applicable "+incomeTax);
	//	System.out.println("Is Employee eligible for ESOP "+isEligibleForESOP);
	}

}
