package com.mahatuis.anu;

import java.io.Serializable;

public class Employee implements Serializable{

	String empId;
	String empName;
	int empSalary;
	Address address;
	
	public Employee() {
		super();
	}
/**/
	public Employee(String empId, String empName, int empSalary, Address address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.address = address;
	}
/*
	public Employee(String empId, String empName, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}*/
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
/* MODEL class : schema Table : No Business logic
 * Data Members/Constructors/Getters/Setters/toString
 * POJO - PLAIN OLD JAVA OBJECT*/
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", address=" + address
				+ "]";
	}
	/*
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}*/

	
	
	
	
}
