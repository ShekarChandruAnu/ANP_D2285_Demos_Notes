package com.maha.anu;

public class StaticSample {

	int nonStaticVar;
	static int staticVar;
	/*
	 * static method can be access only static variables
	 * non static method can access both static and non static variables
	 */
	public static void staticMethod1()
	{
		staticVar++;
		System.out.println("The Static Variable in StaticMethod 01  is :"+staticVar);
	}
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in Non StaticMethod 01  is :"+staticVar);
		System.out.println("The NonStatic Variable in Non StaticMethod 01 is :"+nonStaticVar);
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The Static Variable in StaticMethod 02  is :"+staticVar);
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in Non StaticMethod 02  is :"+staticVar);
		System.out.println("The NonStatic Variable in Non StaticMethod 02 is :"+nonStaticVar);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticSample sSample1 = new StaticSample();
		StaticSample.staticMethod1(); //staticVar : 1
		sSample1.nonStaticMethod1(); //staticVar :2     nonStaticVar:1		is it 1	
		sSample1.nonStaticMethod2(); // staticVar: 3	nonStaticVar:2		is it 2
		
		StaticSample sSample2 = new StaticSample();
		StaticSample.staticMethod2(); //staticVar : 4
		sSample2.nonStaticMethod1();  // staticVar : 5	nonStaticVar:3  or 1 is it 1	
		sSample2.nonStaticMethod2(); // staticVar: 6    nonSTaticVar: 4  or 2 is it 2	
	}

}
