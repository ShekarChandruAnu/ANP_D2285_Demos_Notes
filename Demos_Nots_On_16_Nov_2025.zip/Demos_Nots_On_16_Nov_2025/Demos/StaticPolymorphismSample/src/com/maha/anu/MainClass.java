package com.maha.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass dc = new DerivedClass();
		dc.display1();
		dc.display2();
		dc.display(); // LATE BINDING

	}

}
