package com.krpura.anu;

import java.util.StringTokenizer;

public class StringManipulator {
	public void treatTokens()
	{
		StringTokenizer strTokenizer = new StringTokenizer("India:is:Incredible",":") ;
		while(strTokenizer.hasMoreElements())
		{
			System.out.println("Token is : "+strTokenizer.nextElement());
		}
	}
	public void mutateString()
	{
		// STRINGBUFFER IS SYNCHRONIZED
		StringBuffer sbfr = new StringBuffer("World is beautiful");
		char str[] = {'r','e','a','l','l','y'};
		sbfr.insert(8, str);
		System.out.println("The Mutated String is "+sbfr);
		//sbfr.length();
		System.out.println("The length of sbfr is "+sbfr.length());
		sbfr.append(" also peaceful");
		System.out.println("New sbfr "+sbfr);
	 
		//STRINGBUILDER IS NOT SYNCHRONIZED
		StringBuilder sblr = new StringBuilder("World is beautiful");
		char str1[] = {'r','e','a','l','l','y'};
		sblr.insert(8, str1);
		
		System.out.println("The Mutated String is "+sblr);
		System.out.println("The length of sblr is "+sblr.length());
	}
	public void manipulateString()
	{
		String str1 = "Hyderabad";
		String str2 = "Hyderabad";
		
		// ==    vs equals 
		System.out.println(" str1 == str2 :"+(str1==str2));
		System.out.println("str1.equals(str2) :"+str1.equals(str2));
		
		String str3 = new String("Hyderabad");
		String str4 = new String("Hyderabad");
		
		System.out.println(" str3 == str4 :"+(str3==str4)); //T VS F
		System.out.println("str3.equals(str4) :"+str3.equals(str4)); //T
		
		String str5 = "Bangalore";
		String str6 = "Chennai";
		
		System.out.println(" str5 == str6 :"+(str5==str6)); //T VS F
		System.out.println("str5.equals(str6) :"+str5.equals(str6)); //T
		
		str5 = str6;
		
		System.out.println(" str5 == str6 :"+(str5==str6)); //T VS F
		System.out.println("str5.equals(str6) :"+str5.equals(str6)); //T
		
		String strx = "world is beautiful";
		
		System.out.println("The Length of the String "+strx+"  is "+strx.length());
		System.out.println(" strx.indexOf(i) " +strx.indexOf('i'));
		System.out.println(" strx.codePointAt(4) :"+strx.codePointAt(4));
		System.out.println("strx.substring(6)  :"+strx.substring(6));
		String stry = "Coimbatore";
		String strz = "coimbatore";
		System.out.println( "  stry.compareTo(strz) :"+stry.compareTo(strz) );
		
		String stra = "coimbatore";
		String strb = "Coimbatore";
		System.out.println( "  stra.compareTo(strz) :"+stra.compareTo(strb) );
		
		String stra1 = "New Delhi";
		String strb1 = "New Jersey";
		System.out.println( "  stra1.compareTo(strb1) :"+stra1.compareTo(strb1) );
		
		System.out.println( " stra1.concat(strb1)  :"+stra1.concat(strb1));
		
	}
// COMPARATOR COMPARABLE
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringManipulator smanip = new StringManipulator();
	//	smanip.manipulateString();
		//smanip.mutateString();
		smanip.treatTokens();
	}

}
