package com.mahatumku.anu;

class MyThread implements Runnable 
{
	Thread t1;
	public MyThread()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start(); // - RUNNABLE
	}

	@Override
	public void run() { // RUNNING
		// TODO Auto-generated method stub
		System.out.println("Entering Child Thread.....");//2
		System.out.println("In the Child Thread....");//3
		System.out.println("Exiting Child Thread....");//4
		}// TERMINATED
}
public class RunnableThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" In The Main Thread....");//1
		MyThread mt = new MyThread(); //UNSTARTED
		
		System.out.println("Exiting Main Thread....");//5

	}

}
