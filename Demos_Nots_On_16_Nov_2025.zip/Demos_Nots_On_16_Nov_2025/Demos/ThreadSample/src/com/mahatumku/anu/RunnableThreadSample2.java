package com.mahatumku.anu;
class RunnableThread implements Runnable
{
	Thread t1;
	public RunnableThread()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In the Child Thread....");
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Exiting Child Thread...");
		
	}
	
}
public class RunnableThreadSample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread ABout to invoke Child Thread....");
		RunnableThread rt = new RunnableThread();
		for(int i=0;i<5;i++)
		{
			try {
				System.out.println("Main Thread Loop "+(i+1));
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Back in Main , Exiting Main Thread....");

	}

}
