package com.anu.beans;

public class EmployeeBean {
	
	String empId;
	String empName;
	String empAddress;
	
	public EmployeeBean()
	{
		
	}
	
	public EmployeeBean(String empId, String empName, String empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
	}

	public EmployeeBean(String empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public EmployeeBean(String empId) {
		super();
		this.empId = empId;
	}

	public String getMessage()
	{
		return "Welcome to Spring MVC Framework...";
	}
	
	public void displayEmployeeDetails()
	{
		System.out.println("Employee Details are ....");
		System.out.println("Employee Id :"+empId);
		System.out.println("Employee Name :"+empName);
		System.out.println("Employee Addresss :"+empAddress);
	}

}
