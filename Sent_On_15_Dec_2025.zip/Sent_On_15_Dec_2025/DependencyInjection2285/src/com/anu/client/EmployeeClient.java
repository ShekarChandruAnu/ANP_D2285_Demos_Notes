package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.EmployeeBean;

public class EmployeeClient {
//IOC ApplicationContext
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeBean eBean = context.getBean("empBean", EmployeeBean.class);
		System.out.println("Emp Bean Injected"+eBean.getMessage());
		
		System.out.println("---------------");
		EmployeeBean eBean1 = context.getBean("empBean1",EmployeeBean.class);
		eBean1.displayEmployeeDetails();
		
		EmployeeBean eBean2 = context.getBean("empBean2",EmployeeBean.class);
		eBean2.displayEmployeeDetails();
		

	}

}
