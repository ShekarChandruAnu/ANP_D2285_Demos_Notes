package com.anu.beans;

import java.util.List;

public class Customer {
	
	String customerId;
	String customerName;
	float purchaseValue;
	List <Product> products;
	/*
	public Customer() {
		super();
	}*/

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public float getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public void displayCustomerDetails()
	{
		System.out.println("The Customer Details are...");
		System.out.println("Customer Id :"+customerId);
		System.out.println("Customer Name :"+customerName);
		System.out.println("Purchased Goods worth  "+purchaseValue);
		System.out.println("The Products Purchased by the Customer are...");
		for(Product product : products)
		{
			System.out.println(product);
		}
	}
	

}
