package com.anu.beans;

public class SampleClass {

	int score;
	
/*	public SampleClass() {
		super();
		score= 85;
	}*/
	public SampleClass(int score) {
		super();
		this.score = score;
	}/**/
	public void displayScore()
	{
		System.out.println("Score is "+score);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	SampleClass sc = new SampleClass();
		sc.displayScore();*/
		SampleClass sc1 = new SampleClass(95);
		sc1.displayScore();/**/
		
		

	}

}
