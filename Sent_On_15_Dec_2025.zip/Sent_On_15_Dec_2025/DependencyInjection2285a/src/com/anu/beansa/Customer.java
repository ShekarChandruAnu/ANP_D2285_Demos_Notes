package com.anu.beansa;

import java.util.List;

public class Customer {
	
	String customerId;
	String customerName;
	float purchaseValue;
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public float getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", purchaseValue="
				+ purchaseValue + "]";
	}

	
	
}
