package com.anu.beansa;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class PurchaseDetails {

	String counterId;
	String salesMan;
	Map <Customer,Product>  purchases;
	public String getCounterId() {
		return counterId;
	}
	public void setCounterId(String counterId) {
		this.counterId = counterId;
	}
	public String getSalesMan() {
		return salesMan;
	}
	public void setSalesMan(String salesMan) {
		this.salesMan = salesMan;
	}
	public Map<Customer, Product> getPurchases() {
		return purchases;
	}
	public void setPurchases(Map<Customer, Product> purchases) {
		this.purchases = purchases;
	}
	public void displayPurchaseDetails() {
		System.out.println("Displaying Purchase Details ");
		System.out.println("Counter  Id "+counterId);
		System.out.println("SalesMan who did Sales :"+salesMan);
		// 
		Set <Customer> myKeySet = purchases.keySet();
		Iterator <Customer> keyIter = myKeySet.iterator();
		while(keyIter.hasNext())
		{
			Customer customer  = keyIter.next();
			System.out.println("The Product Purchased by the Customer "+customer+" is :"+purchases.get(customer));
		}
		
		
	}
	
}
