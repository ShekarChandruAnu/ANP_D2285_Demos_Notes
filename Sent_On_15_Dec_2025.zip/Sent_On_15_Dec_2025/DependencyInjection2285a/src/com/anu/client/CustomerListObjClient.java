package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Customer;

public class CustomerListObjClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("customerAppContext.xml");
		
	Customer customer1 = context.getBean("Cust01", Customer.class);
		customer1.displayCustomerDetails();
		System.out.println("----------");
		Customer customer2 = context.getBean("Cust02", Customer.class);
		customer2.displayCustomerDetails();/*	*/
		
		/*Customer customerx = context.getBean("prod1", Customer.class);
		customerx.displayCustomerDetails();*/
		
						

	}

}
