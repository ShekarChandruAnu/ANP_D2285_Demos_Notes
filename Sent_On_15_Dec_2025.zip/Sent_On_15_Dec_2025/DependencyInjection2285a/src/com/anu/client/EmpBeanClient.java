package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Employee;

public class EmpBeanClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");
		Employee employee1 = context.getBean("emp1",Employee.class);
		Employee employee2 = context.getBean("emp2",Employee.class);
		System.out.println("Employee Injected are ...");
		System.out.println(employee1);
		System.out.println(employee2);
		

	}

}
