package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beansa.PurchaseDetails;

public class purchaseDetailsClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("purchaseDetailsAppContext.xml");
		PurchaseDetails pDetails1 = context.getBean("purchDet1", PurchaseDetails.class);
		pDetails1.displayPurchaseDetails();
		System.out.println("_-----_");
		PurchaseDetails pDetails2 = context.getBean("purchDet2", PurchaseDetails.class);
		pDetails2.displayPurchaseDetails();
		
		

	}

}
