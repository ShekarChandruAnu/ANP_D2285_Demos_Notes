package com.anu.beans;

public class Address {

	String dNo;
	String street;
	String area;
	String city;
	String state;
	
	public Address() {
		super();
	}

	public Address(String dNo, String street, String area, String city, String state) {
		super();
		this.dNo = dNo;
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [dNo=" + dNo + ", street=" + street + ", area=" + area + ", city=" + city + ", state=" + state
				+ "]";
	}
	
	
}
