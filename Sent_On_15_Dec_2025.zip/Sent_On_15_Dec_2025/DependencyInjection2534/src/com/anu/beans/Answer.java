package com.anu.beans;

public class Answer {
	
	String ansId;
	String answeredBy;
	String answer;
	
	public Answer() {
		super();
	}

	public Answer(String ansId, String answeredBy, String answer) {
		super();
		this.ansId = ansId;
		this.answeredBy = answeredBy;
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Answer [ansId=" + ansId + ", answeredBy=" + answeredBy + ", answer=" + answer + "]";
	}
	
	

}
