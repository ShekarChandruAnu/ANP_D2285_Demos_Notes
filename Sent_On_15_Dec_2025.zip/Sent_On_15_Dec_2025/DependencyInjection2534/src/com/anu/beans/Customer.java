package com.anu.beans;

import java.util.List;

public class Customer {
	
	String customerId;
	String customerName;
	List <String> products;

	public Customer() {
		super();
	}
	
	public Customer(String customerId, String customerName, List<String> products) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.products = products;
	}

	public void displayCustomer()
	{
		System.out.println("---------Customer Details are----------");
		System.out.println("Customer Id :"+customerId);
		System.out.println("Customr Name :"+customerName);
		System.out.println("Customer Purchased the following Products.......");
		for(String product:products)
		{
			System.out.println(product);
		}
	}
	

}
