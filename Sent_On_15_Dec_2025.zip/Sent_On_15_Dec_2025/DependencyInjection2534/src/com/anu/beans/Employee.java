package com.anu.beans;

public class Employee {
	
		String empId;
		String empName;
		Address empAddress;
		
		public Employee() {
			super();
		}
		public Employee(String empId, String empName, Address empAddress) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.empAddress = empAddress;
		}
		
		public void displayEmployeeDetails()
		{
			System.out.println("-------------Employee Details are--------------");
			System.out.println("Employee Id :"+empId);
			System.out.println("Employee Name :"+empName);
			System.out.println("----------Address details are----------");
			System.out.println(empAddress);
		}
		
		

}
