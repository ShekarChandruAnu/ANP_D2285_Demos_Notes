package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Customer;

public class CustomerClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext1.xml");
		Customer customer1  = ctx.getBean("cust1", Customer.class);
		customer1.displayCustomer();
		System.out.println("--------");
		Customer customer2 = ctx.getBean("cust2", Customer.class);
		customer2.displayCustomer();
		
		
		
	}

}
