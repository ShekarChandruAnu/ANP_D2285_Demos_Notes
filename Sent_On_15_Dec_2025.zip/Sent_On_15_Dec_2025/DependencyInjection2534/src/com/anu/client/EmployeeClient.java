package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Employee;

public class EmployeeClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee employee1 = ctx.getBean("emp1", Employee.class);
		employee1.displayEmployeeDetails();
		
		Employee employee2 = ctx.getBean("emp2", Employee.class);
		employee2.displayEmployeeDetails();
		

	}

}







