package com.anu.beans;

import java.util.List;

public class Question {
	
	String questId;
	String question;
	List <Answer> answers;
	/*
	public Question() {
		super();
	}*/
//Question q = new Question()
	public Question(String questId, String question, List<Answer> answers) {
		super();
		this.questId = questId;
		this.question = question;
		this.answers = answers;
	}/**/
	/* Question q1 = new Question()
	 Question q2 = new Question(a,b,c)*/
	public void displayQuestionAndAnswersBy()
	{
		System.out.println("-----Question Is : ------");
		System.out.println("Question Id :"+questId);
		System.out.println("Question is :"+question);
		System.out.println("Answers as Given By the following People ......");
		for(Answer answer:answers)
		{
			System.out.println(answer);
		}
	}
	
	

}
