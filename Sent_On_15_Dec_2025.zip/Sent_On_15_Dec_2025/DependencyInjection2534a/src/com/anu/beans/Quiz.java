package com.anu.beans;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Quiz {

	String groupId;
	String topic;
	Map <String,String> questAns;
	
	public Quiz() {
		super();
	}

	public Quiz(String groupId, String topic, Map<String, String> questAns) {
		super();
		this.groupId = groupId;
		this.topic = topic;
		this.questAns = questAns;
	}
	public void displayQuizzes()
	{
		System.out.println("The Quiz Details are ...");
		System.out.println("The Group Id :"+groupId);
		System.out.println("The Topic is :"+topic);
		Set <Entry <String,String>> myEntrySet = questAns.entrySet();
		Iterator <Entry<String,String>> entryIter = myEntrySet.iterator();
		while(entryIter.hasNext())
		{
			Entry <String,String> myEntry = entryIter.next();
			System.out.println("The Question is :"+myEntry.getKey()+" And Corresponding Answer is :"+myEntry.getValue());
		}
	}
	
	
}
