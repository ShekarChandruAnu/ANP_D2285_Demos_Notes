package com.anu.beans1;

public class Answer {

		String ansId;
		String answer;
		public Answer() {
			super();
		}
		public Answer(String ansId, String answer) {
			super();
			this.ansId = ansId;
			this.answer = answer;
		}
		@Override
		public String toString() {
			return "Answer [ansId=" + ansId + ", answer=" + answer + "]";
		}
		
		
	
}
