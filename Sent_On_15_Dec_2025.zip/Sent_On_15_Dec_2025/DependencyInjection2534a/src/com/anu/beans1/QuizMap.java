package com.anu.beans1;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class QuizMap {

	String quizId;
	String topic;
	String question;
	Map <User,Answer> answers;
	
	public QuizMap() {
		super();
	}

	public QuizMap(String quizId, String topic, String question, Map<User, Answer> answers) {
		super();
		this.quizId = quizId;
		this.topic = topic;
		this.question = question;
		this.answers = answers;
	}
	
	public void displayQuizDetails()
	{
		System.out.println("The Quiz Details are.....");
		System.out.println("The Quiz Id is :"+quizId);
		System.out.println("The Topic of the Quiz is "+topic);
		System.out.println("The Question is "+question);
		System.out.println("The Users & corresponding Answers are....");
		
		Set <User> myKeys =  answers.keySet();
		Iterator <User> myKeyIter = myKeys.iterator();
		while(myKeyIter.hasNext())
		{
			User myUser = myKeyIter.next();
			System.out.println("The User is "+myUser);
			System.out.println(" And the Corresponding Answer is "+answers.get(myUser));
			System.out.println("--------");
		}
		
	}
	
	 
}
