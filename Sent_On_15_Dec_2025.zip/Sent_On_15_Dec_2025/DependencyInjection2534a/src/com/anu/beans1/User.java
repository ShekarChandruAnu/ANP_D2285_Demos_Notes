package com.anu.beans1;

public class User {
		
		String userId;
		String userName;
		String userDesignation;
				
		public User() {
			super();
		}

		public User(String userId, String userName, String userDesignation) {
			super();
			this.userId = userId;
			this.userName = userName;
			this.userDesignation = userDesignation;
		}

		@Override
		public String toString() {
			return "User [userId=" + userId + ", userName=" + userName + ", userDesignation=" + userDesignation + "]";
		}
		
		
		
		
	
}
