package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Customer;

public class CustomerClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Customer customer1  = context.getBean("cust1", Customer.class);
		customer1.displayCustomer();
		System.out.println("-------");
		Customer customer2 = context.getBean("cust2",Customer.class);
		customer2.displayCustomer();
		

	}

}
