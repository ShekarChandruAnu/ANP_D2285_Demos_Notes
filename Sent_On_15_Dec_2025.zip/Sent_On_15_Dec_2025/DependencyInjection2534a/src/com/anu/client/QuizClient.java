package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Question;

public class QuizClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("quizAppContext.xml");
		Question quest1 = context.getBean("q1", Question.class);
		quest1.displayQuestionAndAnswersBy();
		System.out.println("--------");
		Question quest2 = context.getBean("q2", Question.class);
		quest2.displayQuestionAndAnswersBy();
		
		

	}

}
