package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans.Quiz;

public class QuizMapClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("quizMapAppContext.xml");
		Quiz quiz1 = context.getBean("group1Quiz",Quiz.class);
		quiz1.displayQuizzes();
		System.out.println("---------");
		Quiz quiz2 = context.getBean("group2Quiz",Quiz.class);
		quiz2.displayQuizzes();

	}

}
