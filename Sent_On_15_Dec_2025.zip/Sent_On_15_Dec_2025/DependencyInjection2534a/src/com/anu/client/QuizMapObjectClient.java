package com.anu.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anu.beans1.QuizMap;

public class QuizMapObjectClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("quizMapObjAppContext.xml");
		QuizMap quizMap1 = context.getBean("QuizMap1", QuizMap.class);
		quizMap1.displayQuizDetails();
		System.out.println("--------");
		QuizMap quizMap2 = context.getBean("QuizMap2", QuizMap.class);
		quizMap2.displayQuizDetails();
		

	}

}
