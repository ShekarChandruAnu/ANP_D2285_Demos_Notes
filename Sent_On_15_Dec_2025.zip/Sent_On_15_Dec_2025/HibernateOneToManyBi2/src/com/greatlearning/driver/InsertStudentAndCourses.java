package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Course;
import com.greatlearning.entity.Student;

public class InsertStudentAndCourses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create session factory
				SessionFactory factory = new Configuration()
											.configure("hibernate.cfg.xml")
											.addAnnotatedClass(Student.class)
											.addAnnotatedClass(Course.class)
											.buildSessionFactory();
				
				// create session
				Session session = factory.getCurrentSession();

				try {
					
					// start transaction
					session.beginTransaction();

					// create the objects
					Student tempStudent = new Student("Mahendra", "Kumar", "mahendra@greatlearning.com");
					
					Course course1 = new Course("MongoDB");
					Course course2 = new Course("ReactJS");
					
					tempStudent.add(course1);
					tempStudent.add(course2);
				
				/*	tempStudent.getCourses().add(course1);
					tempStudent.getCourses().add(course2);*/

					

					// save the student
					session.save(tempStudent);
					
					//save the course
				//	session.save(course1);
				//	session.save(course2);
					

					// commit transaction
					session.getTransaction().commit();
					
					System.out.println("Completed Successfully");

				} finally {
					factory.close();
				}

	}

}
