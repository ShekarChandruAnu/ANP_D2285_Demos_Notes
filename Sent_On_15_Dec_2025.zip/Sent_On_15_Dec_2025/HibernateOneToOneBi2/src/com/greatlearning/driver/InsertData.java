package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Address;
import com.greatlearning.entity.Student;

public class InsertData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create session factory
				SessionFactory factory = new Configuration()
											.configure("hibernate.cfg.xml")
											.addAnnotatedClass(Student.class)
											.addAnnotatedClass(Address.class)
											.buildSessionFactory();

				// create session
				Session session = factory.getCurrentSession();

				try {
					//--------------------------------Student to Address---------
					// create the objects
						Student tempStudent = new Student("HariPrasad", "Thakur", "harip@greatlearning.com");

					Address tempAddress = new Address("Karnataka","Mangalore");

					// associate the objects
					tempStudent.setStudentAddress(tempAddress); /**/
					//--------------------------------Address to Student---------
					
					/*			Address address1 = new Address("Karnataka","Bangalore");
					Student student1 = new Student("Amar","Gupta","amar@gmail.com");
					address1.setStudent(student1); /**/
					

					// start transaction
					session.beginTransaction();

					// save the student
					session.save(tempStudent);
				//	session.save(address1); 

					// commit transaction
					session.getTransaction().commit();

				} finally {
					factory.close();
				}
				/*		Address address1 = new Address("Karnataka","Bangalore");
				Student student1 = new Student("Amar","Gupta","amar@gmail.com");
				address1.setStudent(student1); */

	}

}
