package dec24springmvcb.gl.web;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@RequestMapping("/greet")
	public String sayHello(Model model)
	{
		model.addAttribute("greeting", "Welcome to ThymeleafBased SpringMVC App");
		ArrayList <Student> myStudents = new ArrayList<Student>();
		myStudents.add(new Student("S001","Kiran"));
		myStudents.add(new Student("S002","Suman"));
		myStudents.add(new Student("S003","Kishan"));
		myStudents.add(new Student("S004","Milan"));
		model.addAttribute("students", myStudents);
		return "welcome";
	}

}
