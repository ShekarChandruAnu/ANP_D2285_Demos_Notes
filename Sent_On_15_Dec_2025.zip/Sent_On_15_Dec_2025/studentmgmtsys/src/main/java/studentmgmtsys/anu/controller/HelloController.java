package studentmgmtsys.anu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import studentmgmtsys.anu.model.Student;
import studentmgmtsys.anu.service.StudentService;

@Controller
@RequestMapping("/greet")
public class HelloController {
	
	@Autowired
	StudentService studentSvc;
	
	
	@RequestMapping("/hello")
	public String sayHello(Model model)
	{
		String message = "Welcome to SPRING MVC based Applications - Maven Based Project";
		model.addAttribute("mymessage", message);
		return "welcome";
	}
	
	@RequestMapping("/students")
	public String getStudentsCtrlr(Model model)
	{
		List <Student> students = studentSvc.getStudentsSvc();
		model.addAttribute("mystudents", students);
		return "studentslist";
	}

}
