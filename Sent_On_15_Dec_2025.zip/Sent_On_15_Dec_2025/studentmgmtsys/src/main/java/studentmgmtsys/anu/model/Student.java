package studentmgmtsys.anu.model;

public class Student {
	
	String studId;
	String studName;
	String studAddress;
	String studCourse;
	int score;
	
	public Student() {
		super();
	}

	public Student(String studId, String studName, String studAddress, String studCourse, int score) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studAddress = studAddress;
		this.studCourse = studCourse;
		this.score = score;
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}

	public String getStudCourse() {
		return studCourse;
	}

	public void setStudCourse(String studCourse) {
		this.studCourse = studCourse;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studAddress=" + studAddress + ", studCourse="
				+ studCourse + ", score=" + score + "]";
	}
	
	

}
