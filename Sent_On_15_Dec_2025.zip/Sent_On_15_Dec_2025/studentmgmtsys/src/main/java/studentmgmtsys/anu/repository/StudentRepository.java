package studentmgmtsys.anu.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import studentmgmtsys.anu.model.Student;
// SIMULATING THE DAO LAYER
@Repository
public class StudentRepository {
	
	ArrayList <Student> students; 
	public StudentRepository()
	{
		students = new ArrayList<Student>();
	}
	public List <Student> getAllStudents()
	{
		students.add(new Student("S001","Harsha","Vijayanagar","MCA",89));
		students.add(new Student("S002","SreeHarsha","Jayanagar","MCA",86));
		students.add(new Student("S003","Varsha","Indiranagar","MCA",85));
		students.add(new Student("S004","Harsha Vardhana","Koramangala","MCA",79));
		students.add(new Student("S005","rajesh Kumar","Jayanagar","MCA",69));
		
		return students;
	}

}
