package studentmgmtsys.anu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import studentmgmtsys.anu.model.Student;
import studentmgmtsys.anu.repository.StudentRepository;

@Service
public class StudentService {
	
	
	@Autowired
	StudentRepository studentRepo;
	
	
	public List <Student> getStudentsSvc()
	{
		return studentRepo.getAllStudents();
	}

}
