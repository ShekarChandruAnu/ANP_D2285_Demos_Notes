package dec24springthyme.gl.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@RequestMapping("/greet")
	public String sayHello(Model model)
	{
		model.addAttribute("greeting", "Welcome to SpringMVC-Thymeleaf");
		return "welcome";
	}
	
	


}
