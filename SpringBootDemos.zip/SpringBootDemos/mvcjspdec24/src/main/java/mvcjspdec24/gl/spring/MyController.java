package mvcjspdec24.gl.spring;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import mvcjspdec24.gl.spring.model.Student;
import mvcjspdec24.gl.spring.service.StudentService;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@Autowired
	StudentService studentService;
	
	@RequestMapping("/greet")
	public String sayHello(Model model)
	{
		String greeting="Hi! Welcome to SpringMVC-JSP!!";
		model.addAttribute("greetings", greeting);
		return "welcome";
		//WEB-INF/views/welcome.jsp
	}
	//Model ModelAttribute RequestAttribute
	@RequestMapping("/students")
	public String getStudentData(Model model)
	{
		ArrayList <Student> mystudents = studentService.getStudentsSvc();
		model.addAttribute("students", mystudents);
		return "student-list";
	}

}
