package mvcjspdec24.gl.spring.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mvcjspdec24.gl.spring.dao.StudentDao;
import mvcjspdec24.gl.spring.model.Student;

@Service
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	
	public ArrayList <Student> getStudentsSvc()
	{
		ArrayList <Student> students = studentDao.getStudentsDao();
		return students;
	}

}
