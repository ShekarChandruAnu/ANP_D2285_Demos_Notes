package mvcthymedec24.gl.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import mvcthymedec24.gl.model.Student;



@Repository
public class StudentDao {

	ArrayList <Student> students;
	
	public ArrayList<Student> getStudentsDao()
	{
		students = new ArrayList<Student>();
		students.add(new Student("S001","Harsha",89));
		students.add(new Student("S002","Suman",82));
		students.add(new Student("S003","Mahesh",87));
		return students;
	}
}
