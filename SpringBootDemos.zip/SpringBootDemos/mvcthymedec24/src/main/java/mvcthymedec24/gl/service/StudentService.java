package mvcthymedec24.gl.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mvcthymedec24.gl.dao.StudentDao;
import mvcthymedec24.gl.model.Student;



@Service
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	
	public ArrayList <Student> getStudentsSvc()
	{
		ArrayList <Student> students = studentDao.getStudentsDao();
		return students;
	}

}
