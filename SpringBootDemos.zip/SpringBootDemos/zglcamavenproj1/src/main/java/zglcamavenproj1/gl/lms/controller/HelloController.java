package zglcamavenproj1.gl.lms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greet")
public class HelloController {
	
	@RequestMapping("/hello")
	public String sayHello(Model model)
	{
		String myMessage = "Welcome to Maven Based SpringMVC Project";
		model.addAttribute("message",myMessage);
		return "welcome";
	}

}
