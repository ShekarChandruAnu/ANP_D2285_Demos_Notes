package zglcamaventhyme.gl.thyme.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import zglcamaventhyme.gl.thyme.entity.Student;
import zglcamaventhyme.gl.thyme.service.MyService;

@Controller
@RequestMapping("/greet")
public class MyController {

	@Autowired 
	MyService myService;
	
	@RequestMapping("/hello")
	public String sayHello(Model model)
	{
		String greetings="Welcome to Maven Based Thymeleaf Based Configuration Class based App";
		model.addAttribute("mygreeting", greetings);
		return "welcome";
	}
	
	@RequestMapping("/getStudents")
	public String getStudentDetails(Model model)
	{
		List <Student> students = myService.getStudents();
		model.addAttribute("mystudents", students);
		return "studentdata";
	}
}
