package zglcamaventhyme.gl.thyme.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import zglcamaventhyme.gl.thyme.entity.Student;

@Service
public class MyService {
	
	List <Student> students;
	public MyService()
	{
		students = new ArrayList<Student>();
		students.add(new Student("S001","Harsha","RTNagar"));
		students.add(new Student("S002","Kiran","Koramangala"));
		students.add(new Student("S003","Mahesh","Malleswaram"));
		
		students.add(new Student("S004","Keerthana","RTNagar"));
	}
	
	public List <Student> getStudents()
	{
		return students;
	}

}
